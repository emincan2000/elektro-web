"""Türkçe."""

MESSAGES = {
    # --- genel -------------------------------------------------------------------
    "fmt.pct": "%{v}",
    "ui.error": "Hata",
    "ui.warning": "Uyarı",
    "ui.metavar.value": "DEĞER",
    "ui.metavar.values": "DEĞERLER...",
    "common.positive": "değer pozitif olmalı",
    "common.positive_all": "değerler pozitif olmalı",
    "units.empty": "boş değer",
    "units.invalid": "'{text}' anlaşılamadı (örnek: 1k, 4k7, 100n, 2.2u, 1e-3)",
    "units.unknown_series": "bilinmeyen seri '{name}' (seçenekler: {options})",

    # --- Typer / Click -------------------------------------------------------------
    "typer.options": "Seçenekler",
    "typer.arguments": "Argümanlar",
    "typer.commands": "Komutlar",
    "typer.error": "Hata",
    "typer.aborted": "İptal edildi.",
    "typer.required": "[zorunlu]",
    "typer.default": "[varsayılan: {}]",
    "typer.try_help": "Yardım için [blue]'{command_path} {help_option}'[/] yazın.",
    "typer.help_option": "Bu mesajı göster ve çık.",

    # --- ana CLI ---------------------------------------------------------------------
    "cli.help": "Terminal tabanlı Elektrik-Elektronik Mühendisliği aracı.",
    "cli.help_long": (
        "⚡ Elektrik-Elektronik Mühendisliği hesaplamaları için terminal aracı.\n\n"
        "Değerler mühendislik gösterimiyle yazılabilir: 4k7, 100n, 2.2u, 10M, 1meg"
    ),
    "cli.opt.version": "Sürümü göster",
    "cli.opt.lang": "Bu çalıştırma için arayüz dili (en, tr, de, ru)",
    "panel.basic": "Temel",
    "panel.passive": "Pasif elemanlar",
    "panel.signal": "Sinyal & RF",
    "panel.tools": "Araçlar",
    "menu.ohm": "Ohm kanunu ve güç",
    "menu.resistor": "Renk kodu, SMD kodu",
    "menu.555": "NE555 zamanlayıcı",
    "menu.logic": "Tabanlar, kapılar, ifadeler",
    "menu.combine": "Seri/paralel eşdeğer",
    "menu.divider": "Gerilim bölücü",
    "menu.led": "LED ön direnci",
    "menu.eseries": "Standart değerler",
    "menu.cap": "Kondansatör kodu",
    "menu.filter": "RC/RL/LC/RLC filtreler",
    "menu.rf": "FSPL, link bütçesi, anten",
    "menu.datasheet": "Datasheet bul ve indir",
    "menu.helpall": "Tüm komutların kılavuzu",
    "menu.language": "Dili değiştir",
    "menu.update": "Son sürüme güncelle",
    "menu.subtitle": "elektro KOMUT --help",

    # --- dil ------------------------------------------------------------------------------
    "lang.help": (
        "Arayüz dilini göster veya değiştir.\n\n"
        "Örnekler:\n"
        "  elektro language          (dilleri listele)\n"
        "  elektro language de       (Almancayı varsayılan yap)\n"
        "  elektro --lang ru ohm -v 5 -r 1k   (tek seferlik)"
    ),
    "lang.arg": "Kaydedilecek dil kodu",
    "lang.usage": "Değiştir: elektro language KOD   ·   tek seferlik: elektro --lang KOD ...",
    "lang.unknown": "bilinmeyen dil '{code}' (seçenekler: {options})",
    "lang.saved": "Dil {name} olarak ayarlandı.",
    "lang.save_failed": "{path} yazılamadı: {error}",
    "lang.env_override": "Not: ELEKTRO_LANG ortam değişkeni tanımlı ve öncelikli.",

    # --- kılavuz / güncelleme ------------------------------------------------------------
    "manual.help": "Tüm komutların ayrıntılı kılavuzu (sayfalayıcıda).",
    "manual.title": "Kullanım Kılavuzu",
    "manual.values": "Değerler mühendislik gösterimiyle yazılabilir:",
    "upd.help": "Elektro'yu GitHub'daki son sürüme günceller.",
    "upd.opt.force": "Sürüm aynı olsa da yeniden kur",
    "upd.fetch_failed": "GitHub'dan sürüm bilgisi alınamadı. İnternet bağlantını kontrol et.",
    "upd.installed": "Kurulu",
    "upd.up_to_date": "Zaten güncel.",
    "upd.pipx": "pipx ile kurulmuş. Yeni kurulum betiğine geçmek için:",
    "upd.dev": "Geliştirme kurulumu görünüyor; repo klasöründe [cyan]git pull[/] yeterli.",
    "upd.updating": "Güncelleniyor…",
    "upd.failed": "güncelleme başarısız",
    "upd.done": "elektro {version} kuruldu.",

    # --- ohm -------------------------------------------------------------------------------
    "ohm.help": (
        "Ohm kanunu: V, I, R, P'den herhangi ikisini ver, diğerlerini hesaplasın.\n\n"
        "V = I·R    P = V·I = I²·R = V²/R\n\n"
        "Parametresiz çalıştırılırsa soru sorarak ilerler.\n\n"
        "Örnekler:\n"
        "  elektro ohm -v 12 -r 1k\n"
        "  elektro ohm -i 20m -p 0.5\n"
        "  elektro ohm"
    ),
    "ohm.opt.v": "Gerilim (V)",
    "ohm.opt.i": "Akım (A), örn: 20m",
    "ohm.opt.r": "Direnç (Ω), örn: 4k7",
    "ohm.opt.p": "Güç (W)",
    "ohm.need_two": "en az 2 değer gerekli",
    "ohm.negative": "direnç ve güç negatif olamaz",
    "ohm.div_zero": "sıfıra bölme — girilen değerlerle devre tanımsız",
    "ohm.conflict": "Verilen değerler birbiriyle tutarsız; ilk iki değer esas alındı.",
    "ohm.title": "Ohm Kanunu",
    "ohm.voltage": "Gerilim (V)",
    "ohm.current": "Akım (I)",
    "ohm.resistance": "Direnç (R)",
    "ohm.power": "Güç (P)",
    "ohm.wizard": "Ohm Kanunu Sihirbazı — bilmediğin değeri boş bırak (Enter)",
    "ohm.ask.v": "Gerilim V",
    "ohm.ask.i": "Akım I",
    "ohm.ask.r": "Direnç R",
    "ohm.ask.p": "Güç P",

    # --- direnç ----------------------------------------------------------------------------
    "res.help": "Direnç renk kodu, SMD kodu ve standart değerler.",
    "res.help_long": (
        "Direnç renk kodu çözücü.\n\n"
        "Bant sırası: rakamlar → çarpan → tolerans → (sıcaklık katsayısı).\n"
        "Renkler kısa kod (k s r a…), IEC kodu (bn bk rd gd…) ya da Türkçe,\n"
        "İngilizce, Almanca veya Rusça ad olarak yazılabilir.\n\n"
        "Örnekler:\n"
        "  elektro resistor k s r a          (1 kΩ ±%5)\n"
        "  elektro resistor sari mor siyah kahverengi kahverengi\n"
        "  elektro resistor encode 4k7\n"
        "  elektro resistor smd 103"
    ),
    "res.decode.help": "Renk bantlarından direnç değerini bulur.",
    "res.decode.arg": "Renk bantları (3-6 adet)",
    "res.encode.help": "Direnç değerinden renk kodunu üretir.",
    "res.encode.arg": "Direnç, örn: 4k7, 220, 1M",
    "res.encode.opt.bands": "Bant sayısı (4 veya 5)",
    "res.encode.opt.tol": "Tolerans % (varsayılan: 4 bantta 5, 5 bantta 1)",
    "res.encode.bad_bands": "bant sayısı 4 veya 5 olmalı",
    "res.encode.title": "Renk Kodu",
    "res.smd.help": "SMD direnç üzerindeki kodu çözer (3/4 hane ve EIA-96).",
    "res.smd.arg": "SMD kodu: 103, 4R7, 1002, 01C",
    "res.smd.title": "SMD Direnç",
    "res.table.help": "Renk kodu referans tablosu.",
    "res.table.title": "Direnç Renk Kodları",
    "res.table.footer": "Tolerans bandı yoksa ±%20. Örnek: elektro resistor k s r a",
    "res.col.code": "Kod",
    "res.col.color": "Renk",
    "res.col.digit": "Rakam",
    "res.col.mult": "Çarpan",
    "res.col.tol": "Tolerans",
    "res.unknown_color": "bilinmeyen renk '{code}'",
    "res.band_count": "3, 4, 5 veya 6 bant girilmeli",
    "res.bad_digit": "{pos}. bant ({color}) rakam bandı olamaz",
    "res.bad_mult": "çarpan bandı {color} olamaz",
    "res.bad_tol": "tolerans bandı {color} olamaz",
    "res.bad_tempco": "sıcaklık katsayısı bandı {color} olamaz",
    "res.cannot_encode": "{value} renk koduyla yazılamaz",
    "res.bad_tol_value": "geçersiz tolerans %{tol} (seçenekler: {options})",
    "res.eia96_range": "EIA-96 kodu 01-96 arasında olmalı",
    "res.smd_invalid": "'{code}' SMD kodu anlaşılamadı (örnek: 103, 4R7, 1002, 01C)",
    "res.see_table": "Renkler için: elektro resistor table",
    "res.title": "Direnç",
    "res.value": "Değer",
    "res.tolerance": "Tolerans",
    "res.range": "Aralık",
    "res.tempco": "Sıcaklık kats.",
    "res.bands": "Bantlar",
    "res.codes": "Kodlar",
    "res.code": "Kod",
    "res.note": "Not",
    "res.rounded": "{value} {bands} bantla tam yazılamıyor, yuvarlandı",
    "res.nearest_std": "En yakın standart",

    # --- seri / paralel ------------------------------------------------------------------
    "combine.series.help": (
        "Seri bağlı elemanların toplamı (varsayılan: direnç).\n\n"
        "Örnekler:\n"
        "  elektro series 1k 2k2 470\n"
        "  elektro series 100n 100n --cap"
    ),
    "combine.parallel.help": (
        "Paralel bağlı elemanların eşdeğeri (varsayılan: direnç).\n\n"
        "Örnekler:\n"
        "  elektro parallel 1k 1k\n"
        "  elektro parallel 10u 22u --cap"
    ),
    "combine.arg.series": "Eleman değerleri, örn: 1k 2k2 470",
    "combine.arg.parallel": "Eleman değerleri, örn: 1k 1k",
    "combine.opt.cap": "Kondansatör olarak hesapla",
    "combine.opt.ind": "Bobin olarak hesapla",
    "combine.item": "{n}. eleman",
    "combine.total": "Toplam",
    "combine.series_title": "Seri Bağlantı",
    "combine.parallel_title": "Paralel Bağlantı",

    # --- gerilim bölücü --------------------------------------------------------------------
    "div.help": (
        "Gerilim bölücü: Vout = Vin · R2 / (R1 + R2)\n\n"
        "R1 ve R2 verilirse çıkışı hesaplar; --vout verilirse standart değerlerden\n"
        "en iyi R1/R2 çiftlerini önerir.\n\n"
        "Örnekler:\n"
        "  elektro divider --vin 12 --r1 10k --r2 4k7\n"
        "  elektro divider --vin 5 --vout 3.3\n"
        "  elektro divider --vin 12 --vout 3.3 --series E12"
    ),
    "div.opt.vin": "Giriş gerilimi (V)",
    "div.opt.r1": "Üst direnç (Vin ile çıkış arası)",
    "div.opt.r2": "Alt direnç (çıkış ile toprak arası)",
    "div.opt.vout": "Hedef çıkış (R1/R2 önerisi için)",
    "div.opt.series": "Öneri için E serisi",
    "div.opt.load": "Çıkışa bağlı yük direnci",
    "div.range": "0 < Vout < Vin olmalı",
    "div.need": "--r1 ve --r2 ya da --vout verilmeli",
    "div.none": "uygun çift bulunamadı",
    "div.title": "Gerilim Bölücü",
    "div.ratio": "Oran",
    "div.current": "Akım",
    "div.unloaded": "Yüksüz Vout",
    "div.col.error": "Hata",
    "div.col.current": "Akım",

    # --- LED ----------------------------------------------------------------------------------
    "led.help": (
        "LED ön direnci hesabı.\n\n"
        "Örnekler:\n"
        "  elektro led --vs 5\n"
        "  elektro led --vs 12 --vf 3.1 -i 15m -n 3"
    ),
    "led.opt.vs": "Besleme gerilimi (V)",
    "led.opt.vf": "LED ileri gerilimi (V). Kırmızı ~2, mavi/beyaz ~3",
    "led.opt.if": "LED akımı (A), örn: 20m",
    "led.opt.count": "Seri bağlı LED sayısı",
    "led.opt.series": "Önerilecek E serisi",
    "led.supply_low": "besleme ({vs} V) LED gerilim düşümünden ({drop} V) büyük olmalı",
    "led.current_pos": "akım pozitif olmalı",
    "led.title": "LED Direnci",
    "led.calc_r": "Hesaplanan R",
    "led.suggested": "Önerilen ({series})",
    "led.real_i": "Gerçek akım",
    "led.power": "Direnç gücü",
    "led.rating": "Önerilen güç sınıfı",
    "led.rating_high": "> 10 W (farklı çözüm düşün)",
    "led.efficiency": "Verim",

    # --- E serisi ------------------------------------------------------------------------------
    "eseries.help": (
        "Bir değere en yakın standart (E3…E192) değerleri gösterir.\n\n"
        "Örnekler:\n"
        "  elektro eseries 4k8\n"
        "  elektro eseries 3.3u -s E12"
    ),
    "eseries.arg": "Aranan değer, örn: 4k8",
    "eseries.opt.series": "Sadece bu seri (örn: E24)",
    "eseries.title": "{value} için standart değerler",
    "eseries.col.series": "Seri",
    "eseries.col.lower": "Alt",
    "eseries.col.upper": "Üst",
    "eseries.col.nearest": "En yakın",
    "eseries.col.error": "Hata",

    # --- kondansatör ----------------------------------------------------------------------------
    "cap.help": (
        "Seramik kondansatör kodunu çözer ya da değerden kod üretir.\n\n"
        "Örnekler:\n"
        "  elektro cap 104       → 100 nF\n"
        "  elektro cap 472K      → 4.7 nF ±%10\n"
        "  elektro cap 22n       → 223"
    ),
    "cap.arg": "Kod (104, 472K) veya değer (100n)",
    "cap.bad_code": "3 haneli kod bekleniyor (örn: 104, 472K)",
    "cap.title": "Kondansatör",
    "cap.code": "Kod",
    "cap.value": "Değer",
    "cap.tolerance": "Tolerans",
    "cap.not_ceramic": "bu değer muhtemelen seramik kondansatör değil",

    # --- filtreler ----------------------------------------------------------------------------
    "flt.help": "RC/RL/LC/RLC filtre analizi ve tasarımı.",
    "flt.response": "Frekans yanıtı",
    "flt.gain": "Kazanç",
    "flt.phase": "Faz",
    "flt.need_two": "{opts} değerlerinden tam olarak ikisini ver",
    "flt.opt.r": "Direnç (Ω), örn: 1k",
    "flt.opt.c": "Kapasitans (F), örn: 100n",
    "flt.opt.l": "Endüktans (H), örn: 10m",
    "flt.opt.fc": "Kesim frekansı (Hz), örn: 1k",
    "flt.opt.f0": "Rezonans frekansı (Hz)",
    "flt.fc": "Kesim frekansı (fc)",
    "flt.omega": "Açısal frekans (ωc)",
    "flt.tau": "Zaman sabiti (τ)",
    "flt.r": "Direnç (R)",
    "flt.c": "Kapasitans (C)",
    "flt.l": "Endüktans (L)",
    "flt.f0": "Rezonans frekansı (f₀)",
    "flt.center": "Merkez frekans (f₀)",
    "flt.bw": "Bant genişliği (BW)",
    "flt.q": "Kalite faktörü (Q)",
    "flt.lower": "Alt kesim",
    "flt.upper": "Üst kesim",
    "flt.rc.help": (
        "RC filtre (varsayılan alçak geçiren). R, C, fc'den ikisini ver.\n\n"
        "fc = 1 / (2πRC)    τ = RC\n\n"
        "Örnekler:\n"
        "  elektro filter rc --r 1k --c 100n\n"
        "  elektro filter rc --fc 1k --c 10n          (R'yi bulur)\n"
        "  elektro filter rc --r 10k --fc 50 --high   (C'yi bulur)"
    ),
    "flt.rc.opt.high": "Yüksek geçiren (C seri, R toprağa)",
    "flt.rc.title_low": "RC Alçak Geçiren Filtre",
    "flt.rc.title_high": "RC Yüksek Geçiren Filtre",
    "flt.rc.note1": "fc'de kazanç -3 dB, faz {phase}; eğim 20 dB/dekad.",
    "flt.rc.note2": "τ süresinde kondansatör son değerinin %63'üne ulaşır, ~5τ'da tamamen dolar.",
    "flt.rl.help": (
        "RL filtre (varsayılan yüksek geçiren). R, L, fc'den ikisini ver.\n\n"
        "fc = R / (2πL)    τ = L / R\n\n"
        "Örnekler:\n"
        "  elektro filter rl --r 1k --l 10m\n"
        "  elektro filter rl --r 100 --fc 10k --low"
    ),
    "flt.rl.opt.low": "Alçak geçiren (L seri, R toprağa)",
    "flt.rl.title_low": "RL Alçak Geçiren Filtre",
    "flt.rl.title_high": "RL Yüksek Geçiren Filtre",
    "flt.lc.help": (
        "LC rezonans. L, C, f'den ikisini ver.\n\n"
        "f₀ = 1 / (2π√(LC))    Z₀ = √(L/C)\n\n"
        "Örnekler:\n"
        "  elektro filter lc --l 10u --c 100n\n"
        "  elektro filter lc --f 433.92M --c 10p     (L'yi bulur)"
    ),
    "flt.lc.title": "LC Rezonans",
    "flt.lc.reactance": "Reaktans (XL = XC)",
    "flt.lc.z0": "Karakteristik empedans",
    "flt.lc.note": "Seri LC rezonansta empedans minimum, paralel LC (tank) rezonansta maksimumdur.",
    "flt.rlc.help": (
        "Seri RLC bant geçiren filtre (çıkış R üzerinden).\n\n"
        "f₀ = 1 / (2π√(LC))   BW = R / (2πL)   Q = f₀ / BW\n\n"
        "Örnek:\n"
        "  elektro filter rlc --r 10 --l 1m --c 100n"
    ),
    "flt.rlc.title": "Seri RLC Bant Geçiren",
    "flt.rlc.note": "Yüksek Q → dar bant, yüksek seçicilik. Düşük Q → geniş bant.",
    "flt.notch.help": (
        "Bant durduran (notch): sinyal yolunda paralel LC tankı, çıkış R üzerinden.\n\n"
        "f₀ = 1 / (2π√(LC))   Q = R / (2πf₀L)\n\n"
        "Örnek (50 Hz şebeke gürültüsü):\n"
        "  elektro filter notch --r 1k --l 1.013 --c 10u"
    ),
    "flt.notch.opt.r": "Yük direnci (Ω)",
    "flt.notch.title": "Bant Durduran (Notch)",
    "flt.notch.f0": "Söndürme frekansı (f₀)",
    "flt.notch.note": "İdeal elemanlarla f₀'da zayıflama sonsuzdur; gerçekte bobin direnci sınırlar.",
    "flt.theory.help": "Filtre türleri ve formüllerin özeti.",
    "flt.theory.title": "Filtre Teorisi",
    "flt.theory.body": (
        "[bold]Alçak geçiren[/]  RC: R seri, C toprağa   ·  RL: L seri, R toprağa\n"
        "[bold]Yüksek geçiren[/] RC: C seri, R toprağa   ·  RL: R seri, L toprağa\n"
        "[bold]Bant geçiren[/]   Seri RLC, çıkış R üzerinden (rezonansta Z minimum)\n"
        "[bold]Bant durduran[/]  Paralel LC tankı sinyal yolunda (rezonansta Z maksimum)\n\n"
        "fc(RC) = 1/(2πRC)     fc(RL) = R/(2πL)\n"
        "f₀(LC) = 1/(2π√(LC))  Q = f₀/BW\n"
        "1. derece filtre: fc'de -3 dB, 20 dB/dekad eğim"
    ),

    # --- RF ----------------------------------------------------------------------------------
    "rf.help": "RF: FSPL, link bütçesi, dalga boyu ve birim dönüşümleri.",
    "rf.metavar.freq": "FREKANS",
    "rf.metavar.dist": "MESAFE",
    "rf.opt.freq": "Frekans. Yalın sayı MHz: 868, 2.4G, 433.92M",
    "rf.opt.dist": "Mesafe. Yalın sayı km: 5, 800m, 12km",
    "rf.bad_distance": "'{text}' mesafe olarak anlaşılamadı (örn: 5, 2.5km, 800m)",
    "rf.positive": "frekans ve mesafe pozitif olmalı",
    "rf.freq": "Frekans",
    "rf.dist": "Mesafe",
    "rf.wavelength": "Dalga boyu",
    "rf.fspl.help": (
        "Serbest uzay yol kaybı (ITU-R P.525).\n\n"
        "FSPL(dB) = 20·log₁₀(d) + 20·log₁₀(f) + 20·log₁₀(4π/c)\n\n"
        "Örnekler:\n"
        "  elektro rf fspl -f 868 -d 5\n"
        "  elektro rf fspl -f 2.4G -d 300m"
    ),
    "rf.fspl.title": "Serbest Uzay Yol Kaybı",
    "rf.fspl.note": "Link marjını görmek için: elektro rf link --help",
    "rf.link.help": (
        "Link bütçesi: alınan güç, link marjı ve teorik maksimum menzil.\n\n"
        "Prx = Ptx + Gtx + Grx − FSPL − kayıplar\n\n"
        "Örnekler:\n"
        "  elektro rf link -f 868 -d 10 --tx 14 --sens -137\n"
        "  elektro rf link -f 2.4G -d 500m --tx 20 --gtx 5 --grx 5 --sens -90 --loss 3"
    ),
    "rf.link.opt.tx": "Verici gücü (dBm)",
    "rf.link.opt.gtx": "Verici anten kazancı (dBi)",
    "rf.link.opt.grx": "Alıcı anten kazancı (dBi)",
    "rf.link.opt.sens": "Alıcı hassasiyeti (dBm)",
    "rf.link.opt.loss": "Kablo/konnektör/ortam kayıpları toplamı (dB)",
    "rf.link.title": "Link Bütçesi",
    "rf.link.prx": "Alınan güç",
    "rf.link.sens": "Hassasiyet",
    "rf.link.margin": "Link marjı",
    "rf.link.solid": "sağlam",
    "rf.link.marginal": "sınırda",
    "rf.link.no_link": "BAĞLANTI YOK",
    "rf.link.range0": "Maks. menzil (0 dB marj)",
    "rf.link.range10": "Maks. menzil (10 dB marj)",
    "rf.link.note1": "Serbest uzay varsayımıdır; engeller, Fresnel bölgesi ve sönümleme menzili ciddi azaltır.",
    "rf.link.note2": "Pratikte 10-20 dB marj bırakılması önerilir.",
    "rf.wave.help": (
        "Dalga boyu ve temel anten boyları.\n\n"
        "Örnekler:\n"
        "  elektro rf wave -f 433.92\n"
        "  elektro rf wave -f 2.4G --vf 0.95"
    ),
    "rf.wave.opt.vf": "Hız faktörü (koaksiyel için ~0.66-0.85, tel anten ~0.95)",
    "rf.wave.bad": "frekans pozitif ve 0 < vf ≤ 1 olmalı",
    "rf.wave.title": "Dalga Boyu",
    "rf.wave.dipole": "λ/2 dipol (toplam)",
    "rf.wave.monopole": "λ/4 monopol / GP",
    "rf.conv.help": (
        "RF birim dönüşümü (güç ve empedans uyumu).\n\n"
        "Örnekler:\n"
        "  elektro rf convert 14 dbm w\n"
        "  elektro rf convert 0.1 w\n"
        "  elektro rf convert 1.5 vswr"
    ),
    "rf.conv.arg.value": "Değer",
    "rf.conv.arg.src": "Kaynak birim: dbm dbw w mw uw vswr rl gamma",
    "rf.conv.arg.dst": "Hedef birim (boşsa hepsi)",
    "rf.conv.vswr": "VSWR ≥ 1 olmalı",
    "rf.conv.rl": "return loss ≥ 0 dB olmalı",
    "rf.conv.gamma": "|Γ| 0 ile 1 arasında olmalı",
    "rf.conv.power_pos": "güç pozitif olmalı",
    "rf.conv.no_path": "{src} → {dst} dönüşümü yok",
    "rf.conv.unknown": "bilinmeyen birim '{unit}'",
    "rf.conv.l.rl": "Return loss",
    "rf.conv.l.mismatch": "Uyumsuzluk kaybı",
    "rf.conv.l.reflected": "Yansıyan güç",

    # --- dijital -----------------------------------------------------------------------------
    "dig.help": "Dijital: sayı tabanları, mantık kapıları, boolean ifadeler.",
    "dig.base_range": "taban 2 ile 36 arasında olmalı",
    "dig.conv.help": (
        "Sayı tabanları arası dönüşüm (2-36).\n\n"
        "Hedef verilmezse ikili, sekizli, onlu ve onaltılı gösterimi birlikte verir.\n\n"
        "Örnekler:\n"
        "  elektro logic convert 255\n"
        "  elektro logic convert 0xFF -t 2\n"
        "  elektro logic convert 1010 -f 2\n"
        "  elektro logic convert --bits 8 -- -5"
    ),
    "dig.conv.arg": "Sayı: 255, 0xFF, 0b1010, 0o17, 1Fh",
    "dig.conv.opt.from": "Kaynak taban (varsayılan: önekten ya da 10)",
    "dig.conv.opt.to": "Sadece bu tabana çevir",
    "dig.conv.opt.bits": "Bit genişliği (negatifler için ikiye tümleyen)",
    "dig.conv.invalid": "'{value}' geçerli bir sayı değil",
    "dig.conv.in_base": " (taban {base})",
    "dig.conv.overflow": "{n} değeri {bits} bite sığmaz ({lo} … {hi})",
    "dig.conv.base": "taban {base}",
    "dig.conv.title": "Sayı Dönüşümü",
    "dig.dec": "Onlu",
    "dig.hex": "Onaltılı",
    "dig.bin": "İkili",
    "dig.oct": "Sekizli",
    "dig.bits": "Bit sayısı",
    "dig.unsigned": "İşaretsiz",
    "dig.truth.help": (
        "Mantık kapısı çıkışı veya (giriş verilmezse) doğruluk tablosu.\n\n"
        "Örnekler:\n"
        "  elektro logic truth xor\n"
        "  elektro logic truth nand -a 1 -b 1"
    ),
    "dig.truth.arg": "Kapı: {gates}",
    "dig.truth.opt.a": "Giriş A (0/1)",
    "dig.truth.opt.b": "Giriş B (0/1)",
    "dig.truth.unknown": "bilinmeyen kapı '{gate}' (seçenekler: {gates})",
    "dig.expr.help": (
        "Boolean ifadenin doğruluk tablosu ve minterm listesi.\n\n"
        "Operatörler: & (VE), | (VEYA), ^ (XOR), ~ (DEĞİL). and/or/xor/not ve ve/veya/değil de yazılabilir.\n\n"
        "Örnekler:\n"
        "  elektro logic expr \"A & B | ~C\"\n"
        "  elektro logic expr \"(A xor B) ve C\""
    ),
    "dig.expr.arg": "Boolean ifade, örn: \"A & B | ~C\"",
    "dig.expr.invalid": "ifade anlaşılamadı: {expr}",
    "dig.expr.unsupported": "desteklenmeyen öğe: {node}",
    "dig.expr.const": "sabit olarak sadece 0 ve 1 kullanılabilir",
    "dig.expr.too_many": "en fazla 6 değişken destekleniyor",

    # --- 555 -------------------------------------------------------------------------------------
    "555.help": "NE555 zamanlayıcı: astable ve monostable.",
    "555.astable.help": (
        "Astable (osilatör) mod.\n\n"
        "f = 1.44 / ((R1 + 2R2)·C)    D = (R1 + R2) / (R1 + 2R2)\n\n"
        "Örnekler:\n"
        "  elektro 555 astable --r1 1k --r2 10k --c 10u\n"
        "  elektro 555 astable -f 1k -d 60 --c 10n     (R1, R2'yi bulur)"
    ),
    "555.mono.help": (
        "Monostable (tek darbe) mod. R, C, t'den ikisini ver.\n\n"
        "t = 1.1 · R · C\n\n"
        "Örnekler:\n"
        "  elektro 555 mono --r 100k --c 10u\n"
        "  elektro 555 mono --t 5 --c 100u     (R'yi bulur)"
    ),
    "555.opt.r1": "R1 (VCC–DIS arası)",
    "555.opt.r2": "R2 (DIS–THR/TRIG arası)",
    "555.opt.c": "Zamanlama kondansatörü",
    "555.opt.r": "Zamanlama direnci",
    "555.opt.t": "Darbe süresi (s)",
    "555.opt.freq": "Hedef frekans (tasarım modu)",
    "555.opt.duty": "Hedef görev oranı % (tasarım modu)",
    "555.duty_range": ("klasik 555 astable'da görev oranı %50'den büyük olmalı "
                       "(daha düşük oran için R2'ye paralel diyot kullanılır)"),
    "555.need": "--r1 ve --r2 ya da --freq verilmeli",
    "555.mono.need": "--r, --c ve --t'den tam olarak ikisini ver",
    "555.design.title": "555 Astable Tasarım",
    "555.r1_calc": "R1 (hesap)",
    "555.r2_calc": "R2 (hesap)",
    "555.real_freq": "Gerçek frekans",
    "555.real_duty": "Gerçek görev oranı",
    "555.range_warn": "Uyarı: R1 ≥ 1 kΩ ve R2 ≤ 1 MΩ aralığı önerilir; kondansatör değerini değiştir.",
    "555.astable.title": "555 Astable",
    "555.freq": "Frekans",
    "555.period": "Periyot",
    "555.t_high": "Yüksek süre",
    "555.t_low": "Düşük süre",
    "555.duty": "Görev oranı",
    "555.mono.title": "555 Monostable",
    "555.pulse": "Darbe süresi",

    # --- datasheet -----------------------------------------------------------------------------
    "ds.help": (
        "Komponent datasheet'ini bulup bulunduğun klasöre indirir.\n\n"
        "Önce üretici sitelerine, sonra LCSC parça veritabanına, en son\n"
        "DuckDuckGo aramasına bakar. İnen dosyanın gerçekten PDF olduğu doğrulanır.\n\n"
        "Örnekler:\n"
        "  elektro datasheet lm358\n"
        "  elektro datasheet ams1117 --open\n"
        "  elektro datasheet 2n2222 -o transistor.pdf\n"
        "  elektro datasheet esp32 --list"
    ),
    "ds.arg.part": "Parça adı, örn: lm358, ne555, ams1117, esp32",
    "ds.opt.output": "Kayıt yolu (varsayılan: <parça>_datasheet.pdf)",
    "ds.opt.open": "İndirdikten sonra PDF'i aç",
    "ds.opt.list": "İndirmeden bulunan adayları listele",
    "ds.opt.force": "Dosya varsa üzerine yaz",
    "ds.opt.max": "Denenecek en fazla aday sayısı",
    "ds.step.maker": "Üretici siteleri kontrol ediliyor",
    "ds.step.lcsc": "LCSC/JLCPCB parça veritabanı aranıyor",
    "ds.step.ddg": "DuckDuckGo'da aranıyor",
    "ds.step.ddg_blocked": "DuckDuckGo şu an bot koruması gösteriyor, atlandı",
    "ds.no_opener": "'{opener}' bulunamadı, dosyayı elle aç: {path}",
    "ds.empty": "parça adı boş olamaz",
    "ds.candidates": "'{part}' için adaylar:",
    "ds.no_candidates": "Aday bulunamadı.",
    "ds.exists": "Dosya zaten var",
    "ds.use_force": "Tekrar indirmek için --force kullan.",
    "ds.no_dir": "klasör yok: {path}",
    "ds.searching": "'{part}' için datasheet aranıyor",
    "ds.downloaded": "İndirildi",
    "ds.try_next": "PDF alınamadı, sıradaki deneniyor",
    "ds.cancelled": "İptal edildi.",
    "ds.nothing": "Hiçbir kaynakta sonuç bulunamadı.",
    "ds.check_net": "İnternet bağlantını ya da parça adını kontrol et.",
    "ds.all_failed": "Bulunan adayların hiçbirinden PDF indirilemedi.",
    "ds.manual": "Elle aramak için:",
}

# --- 0.4: yeni komutlar -----------------------------------------------------------------
MESSAGES.update({
    "cli.opt.json": "Sonuçları JSON olarak yaz (betikler için)",
    "panel.power": "Güç & iletkenler",
    "panel.embedded": "Gömülü sistemler",
    "menu.switch": "Anahtar olarak transistör",
    "menu.charge": "RC/RL dolma eğrisi",
    "menu.regulator": "Voltaj regülatörü",
    "menu.battery": "Batarya ömrü",
    "menu.thermal": "Isı ve soğutucu",
    "menu.wire": "Kablo kesiti, gerilim düşümü",
    "menu.trace": "PCB yol genişliği",
    "menu.uart": "UART baud hatası",
    "menu.pwm": "Timer/PWM kayıtları",
    "menu.adc": "ADC gerilim ↔ kod",
    "menu.i2c": "I²C pull-up direnci",
    "menu.crc": "CRC / checksum",
    "menu.calc": "Birimli hesap makinesi",
    "menu.unit": "Birim dönüştürücü",
    "time.min": "dk",
    "time.hours": "saat",
    "time.days": "gün",
    "time.months": "ay",

    # regülatör
    "reg.help": (
        "Voltaj regülatörü: ayarlılarda direnç hesabı, lineerlerde harcanan güç.\n\n"
        "Ayarlı: lm317, lm1117, ams1117, lm2596, xl4015, mp1584\n"
        "Sabit: 7805, 7812, ams1117-3.3 …\n\n"
        "Örnekler:\n"
        "  elektro regulator lm317 --vout 5\n"
        "  elektro regulator lm317 --r1 240 --r2 720\n"
        "  elektro regulator 7805 --vin 12 -i 500m\n"
        "  elektro regulator ams1117-3.3 --vin 5 -i 300m"
    ),
    "reg.arg": "Regülatör, örn: lm317, 7805, ams1117-3.3",
    "reg.opt.vout": "Hedef çıkış gerilimi (ayarlı regülatörler)",
    "reg.opt.vin": "Giriş gerilimi",
    "reg.opt.iout": "Yük akımı",
    "reg.opt.r1": "R1 (OUT ile ADJ/FB arası); varsayılan: datasheet değeri",
    "reg.opt.r2": "R2 (ADJ/FB ile toprak arası) — Vout'u hesaplar",
    "reg.unknown": "bilinmeyen regülatör '{name}' (bilinenler: {options})",
    "reg.vout_low": "çıkış referans geriliminden ({vref} V) büyük olmalı",
    "reg.need_vout": "--vout ya da çıkışı hesaplamak için --r2 ver",
    "reg.vout": "Çıkış gerilimi",
    "reg.r2_calc": "R2 (hesap)",
    "reg.dropout": "Tipik düşüm (dropout)",
    "reg.headroom": "Vin − Vout",
    "reg.dropout_warn": "Vin − Vout = {headroom} V, tipik düşüm geriliminin ({dropout} V) altında; çıkış düşebilir.",
    "reg.power": "Harcanan güç",
    "reg.efficiency": "Verim",
    "reg.switching_note": "Anahtarlamalı regülatör: kayıp verime bağlıdır (tipik %80-95), datasheet'e bak.",
    "reg.heat_note": "1 W üstü çoğu kılıfta soğutucu ister — kontrol için: elektro thermal --help",

    # batarya
    "bat.help": (
        "Kapasite ve ortalama akımdan (ya da aktif/uyku profilinden) batarya ömrü.\n\n"
        "Örnekler:\n"
        "  elektro battery 2000 -i 15m\n"
        "  elektro battery 1200 --active 45m --active-time 2 --sleep 20u --sleep-time 58"
    ),
    "bat.arg": "Kapasite (mAh)",
    "bat.opt.current": "Ortalama akım (A), örn: 15m",
    "bat.opt.active": "Aktifken çekilen akım (A)",
    "bat.opt.active_time": "Her döngüde aktif süre (s)",
    "bat.opt.sleep": "Uykudayken çekilen akım (A)",
    "bat.opt.sleep_time": "Her döngüde uyku süresi (s)",
    "bat.opt.derate": "Kapasitenin kullanılabilir oranı (yaşlanma, sıcaklık, kesme gerilimi)",
    "bat.need": "-i ya da --active --active-time --sleep --sleep-time değerlerinin hepsini ver",
    "bat.title": "Batarya Ömrü",
    "bat.capacity": "Kapasite",
    "bat.usable": "Kullanılabilir",
    "bat.avg_current": "Ortalama akım",
    "bat.life": "Tahmini ömür",
    "bat.note": "Kendi kendine deşarj ve regülatörün boşta akımı hesaba katılmadı.",

    # ısıl
    "th.help": (
        "Jonksiyon sıcaklığı ve gereken soğutucu.\n\n"
        "Tj = Ta + P · (Rθjc + Rθcs + Rθsa)   ya da   Tj = Ta + P · Rθja\n\n"
        "Örnekler:\n"
        "  elektro thermal -p 2 --rth-ja 62 --ta 40          (soğutucusuz, TO-220)\n"
        "  elektro thermal -p 5 --rth-jc 3 --rth-sa 8\n"
        "  elektro thermal -p 5 --rth-jc 3 --ta 50           (gereken soğutucu)"
    ),
    "th.opt.power": "Harcanan güç (W)",
    "th.opt.ta": "Ortam sıcaklığı (°C)",
    "th.opt.tjmax": "Maksimum jonksiyon sıcaklığı (°C)",
    "th.opt.rja": "Soğutucusuz jonksiyon-ortam ısıl direnci (°C/W)",
    "th.opt.rjc": "Jonksiyon-kılıf ısıl direnci (°C/W)",
    "th.opt.rcs": "Kılıf-soğutucu (ısı pedi/macun) (°C/W)",
    "th.opt.rsa": "Soğutucu-ortam (°C/W)",
    "th.need": "--rth-ja ya da --rth-jc (--rth-sa ile veya onsuz) ver",
    "th.title": "Isıl Hesap",
    "th.power": "Güç",
    "th.total": "Toplam Rθ",
    "th.need_sa": "Gereken soğutucu Rθsa ≤",
    "th.impossible": "mümkün değil — gücü azalt",
    "th.margin": "Tj max'a kalan pay",
    "th.margin_note": "Bu değerin rahatça altında bir soğutucu seç (~%20-30 pay).",
    "th.over": "Jonksiyon sıcaklığı maksimumu aşıyor!",

    # kablo
    "wire.help": (
        "Bakır kablo: AWG ↔ mm², direnç, gerilim düşümü ve kayıp.\n\n"
        "Örnekler:\n"
        "  elektro wire --awg 22 -l 3 -i 2\n"
        "  elektro wire --mm2 1.5 -l 10 -i 10 --round-trip"
    ),
    "wire.opt.awg": "Kablo kalınlığı (AWG)",
    "wire.opt.mm2": "Kesit (mm²)",
    "wire.opt.length": "Uzunluk (yalın sayı = m): 3, 50cm, 10ft",
    "wire.opt.current": "Akım (A)",
    "wire.opt.round_trip": "Uzunluğu iki kez say (gidiş + dönüş iletkeni)",
    "wire.opt.temp": "İletken sıcaklığı (°C)",
    "wire.metavar.length": "UZUNLUK",
    "wire.bad_length": "'{text}' uzunluk olarak anlaşılamadı (örn: 3, 50cm, 10ft)",
    "wire.need": "--awg ya da --mm2'den birini ver",
    "wire.title": "Bakır Kablo",
    "wire.diameter": "Çap",
    "wire.area": "Kesit",
    "wire.r_per_m": "Metre başına direnç",
    "wire.resistance": "Direnç",
    "wire.drop": "Gerilim düşümü",
    "wire.loss": "Güç kaybı",
    "wire.density": "Akım yoğunluğu",
    "wire.hot": "Akım yoğunluğu yüksek; kablo ısınabilir (> 6 A/mm²).",
    "wire.note": "Tek telli bakır; çok telli kablonun direnci biraz daha yüksektir.",

    # PCB yolu
    "trace.help": (
        "IPC-2221'e göre PCB yol genişliği (ya da bir yolun taşıyabileceği akım).\n\n"
        "Örnekler:\n"
        "  elektro trace -i 3\n"
        "  elektro trace -i 5 --rise 20 --oz 2\n"
        "  elektro trace -w 0.5 --internal -l 40mm"
    ),
    "trace.opt.current": "Akım (A)",
    "trace.opt.width": "Yol genişliği mm (akımı hesaplar)",
    "trace.opt.rise": "İzin verilen sıcaklık artışı (°C)",
    "trace.opt.oz": "Bakır ağırlığı (oz/ft²): 0.5, 1, 2",
    "trace.opt.internal": "İç katman (varsayılan dış katman)",
    "trace.opt.length": "Yol uzunluğu (yalın sayı = m): 40mm, 0.1",
    "trace.need": "-i ya da -w'den birini ver",
    "trace.title": "PCB Yolu (IPC-2221)",
    "trace.width": "Genişlik",
    "trace.current": "Akım",
    "trace.thickness": "Bakır",
    "trace.layer": "Katman",
    "trace.internal": "iç",
    "trace.external": "dış",
    "trace.rise": "Sıcaklık artışı",
    "trace.note": "IPC-2221 temkinlidir; yüksek akımlarda IPC-2152'ye de bak.",

    # transistör anahtar
    "sw.help": "Anahtar olarak transistör: BJT taban direnci, MOSFET kapı sürme.",
    "sw.opt.vdrive": "Sürme gerilimi (örn: GPIO 3.3 ya da 5 V)",
    "sw.bjt.help": (
        "Doyumda çalışan BJT (NPN) anahtar: taban direnci ve kayıplar.\n\n"
        "Ib = Ic / hFE · k     Rb = (Vsürme − Vbe) / Ib\n\n"
        "Örnekler:\n"
        "  elektro switch bjt --ic 500m -v 3.3\n"
        "  elektro switch bjt --vcc 12 --rload 24 -v 5 --hfe 150"
    ),
    "sw.bjt.opt.ic": "Kollektör (yük) akımı",
    "sw.bjt.opt.hfe": "Minimum akım kazancı hFE (datasheet'ten)",
    "sw.bjt.opt.overdrive": "Sağlam doyum için aşırı sürme katsayısı k (2-5)",
    "sw.bjt.opt.vbe": "Baz-emiter gerilimi (V)",
    "sw.bjt.opt.vcesat": "Kollektör-emiter doyum gerilimi (V)",
    "sw.bjt.opt.vcc": "Besleme gerilimi (--rload ile, --ic yerine)",
    "sw.bjt.opt.rload": "Yük direnci (--vcc ile)",
    "sw.bjt.need": "--ic ya da --vcc ve --rload ver",
    "sw.bjt.vdrive_low": "sürme gerilimi Vbe'den ({vbe} V) büyük olmalı",
    "sw.bjt.title": "BJT Anahtar",
    "sw.bjt.ib": "Gereken Ib",
    "sw.bjt.rb_calc": "Rb (hesap)",
    "sw.bjt.rb_std": "Rb (E12, bir alt)",
    "sw.bjt.forced_beta": "Zorlanmış β (Ic/Ib)",
    "sw.bjt.p_transistor": "Transistör kaybı",
    "sw.bjt.p_rb": "Rb gücü",
    "sw.bjt.gpio_warn": "{ib} taban akımı çoğu MCU bacağı için fazla; Darlington ya da MOSFET kullan.",
    "sw.bjt.note": "Endüktif yüklerde (röle, motor) yüke paralel serbest geçiş diyotu ekle.",
    "sw.fet.help": (
        "MOSFET kapı sürme: kapı akımı, anahtarlama süresi ve kayıplar.\n\n"
        "Örnekler:\n"
        "  elektro switch mosfet -v 10 --qg 40n --rg 10 -f 100k\n"
        "  elektro switch mosfet -v 5 --qg 20n -f 20k --id 5 --rds 20m --vds 24"
    ),
    "sw.fet.opt.qg": "Toplam kapı yükü Qg (C), örn: 40n",
    "sw.fet.opt.rg": "Kapı direnci (Ω)",
    "sw.fet.opt.fsw": "Anahtarlama frekansı (Hz)",
    "sw.fet.opt.id": "Drain akımı (A)",
    "sw.fet.opt.rds": "İletim direnci Rds(on) (Ω)",
    "sw.fet.opt.vds": "Kesimdeyken drain-source gerilimi (V)",
    "sw.fet.title": "MOSFET Kapı Sürme",
    "sw.fet.ipeak": "Tepe kapı akımı",
    "sw.fet.tsw": "Anahtarlama süresi (≈ Qg/Ig)",
    "sw.fet.pgate": "Kapı sürme gücü",
    "sw.fet.pcond": "İletim kaybı",
    "sw.fet.psw": "Anahtarlama kaybı (yaklaşık)",
    "sw.fet.ptotal": "Toplam kayıp",
    "sw.fet.slow": "Anahtarlama periyodun %10'undan uzun sürüyor; kapı sürücü ya da daha küçük Rg kullan.",
    "sw.fet.logic_level": "5 V altı sürme: lojik seviye MOSFET kullan (Rds(on) 2.5-4.5 V'ta belirtilmiş).",
    "sw.fet.note": "Tahmindir; gerçek anahtarlama süresi Miller platosuna ve sürücüye de bağlıdır.",

    # dolma
    "chg.help": (
        "Zamana göre RC kondansatör dolması / RL bobin akımı.\n\n"
        "v(t) = Vs + (V0 − Vs) · e^(−t/τ)\n\n"
        "Örnekler:\n"
        "  elektro charge --r 10k --c 100u --v 5\n"
        "  elektro charge --r 10k --c 100u --v 5 --to 3.3      (3.3 V'a kadar süre)\n"
        "  elektro charge --r 10k --c 100u --v 0 --v0 5 --t 1  (boşalma)\n"
        "  elektro charge --r 10 --l 1m --v 12                 (RL akımı)"
    ),
    "chg.opt.r": "Direnç (Ω)",
    "chg.opt.c": "RC için kapasitans (F)",
    "chg.opt.l": "RL için endüktans (H)",
    "chg.opt.v": "Uygulanan (son) gerilim (V)",
    "chg.opt.v0": "Kondansatörün başlangıç gerilimi (V)",
    "chg.opt.to": "Hedef gerilim: ne kadar sürede ulaşılır",
    "chg.opt.t": "Zaman (s): bu andaki değer",
    "chg.need": "--c (RC) ya da --l (RL)'den birini ver",
    "chg.unreachable": "hedefe hiç ulaşılmaz (başlangıç ile son değer arasında değil)",
    "chg.title_rc": "RC Dolma",
    "chg.title_rl": "RL Akımı",
    "chg.final": "Son değer",
    "chg.value_at": "{time} anındaki değer",
    "chg.time_to": "{target} için süre",
    "chg.note": "1τ sonunda değişimin {pct}'ü tamamlanır; 5τ'da pratikte biter.",

    # microstrip
    "ms.help": (
        "Mikroşerit hat: istenen empedans için yol genişliği ya da bir genişliğin empedansı (Hammerstad).\n\n"
        "Örnekler:\n"
        "  elektro rf microstrip --z0 50                   (1.6 mm FR4)\n"
        "  elektro rf microstrip --z0 50 --h 0.2 --er 4.2 -f 2.4G\n"
        "  elektro rf microstrip -w 3"
    ),
    "ms.opt.z0": "Hedef empedans (Ω)",
    "ms.opt.width": "Yol genişliği (mm) — Z0'ı hesaplar",
    "ms.opt.h": "Toprak düzlemine olan dielektrik kalınlığı (mm)",
    "ms.opt.er": "Bağıl dielektrik sabiti εr (FR4 ≈ 4.2-4.6)",
    "ms.need": "--z0 ya da --width'ten birini ver",
    "ms.range": "empedans ulaşılabilir aralığın dışında",
    "ms.title": "Mikroşerit Hat",
    "ms.width": "Yol genişliği",
    "ms.lambda": "Hat üzerindeki dalga boyu",
    "ms.note": "Bakır kalınlığı ve lehim maskesi hesaba katılmadı; son değer için üreticinin hesaplayıcısını kullan.",

    # LoRa
    "lora.help": (
        "LoRa havada kalma süresi, veri hızı, hassasiyet ve görev döngüsü sınırı (Semtech AN1200.13).\n\n"
        "Örnekler:\n"
        "  elektro rf lora --sf 9 -p 20\n"
        "  elektro rf lora --sf 12 --bw 125k --cr 4/8 -p 51"
    ),
    "lora.opt.sf": "Yayılma faktörü (7-12)",
    "lora.opt.bw": "Bant genişliği (Hz): 125k, 250k, 500k",
    "lora.opt.cr": "Kodlama oranı: 4/5 … 4/8",
    "lora.opt.payload": "Veri uzunluğu (bayt)",
    "lora.opt.preamble": "Preamble uzunluğu (sembol)",
    "lora.opt.no_crc": "Veri CRC'si olmadan",
    "lora.opt.implicit": "Örtük başlık (implicit header) modu",
    "lora.opt.duty": "Görev döngüsü sınırı % (AB 868 MHz: 1)",
    "lora.opt.nf": "Alıcı gürültü figürü (dB)",
    "lora.bad_cr": "kodlama oranı 4/5, 4/6, 4/7 ya da 4/8 olmalı",
    "lora.airtime": "Havada kalma süresi",
    "lora.symbol": "Sembol süresi",
    "lora.bitrate": "Veri hızı",
    "lora.sensitivity": "Hassasiyet (yaklaşık)",
    "lora.per_hour": "{duty} ile saatte paket",
    "lora.interval": "her",
    "lora.on": "açık",
    "lora.off": "kapalı",
    "lora.note": "LDRO (düşük veri hızı optimizasyonu) sembol süresi 16 ms'yi aşınca otomatik açılır.",

    # Fresnel
    "fresnel.help": (
        "Birinci Fresnel bölgesi ve görüş hattı için gereken anten yüksekliği.\n\n"
        "r₁ = √(λ·d₁·d₂ / D)\n\n"
        "Örnekler:\n"
        "  elektro rf fresnel -f 868 -d 10\n"
        "  elektro rf fresnel -f 2.4G -d 3 --at 500m"
    ),
    "fresnel.opt.at": "Engelin vericiye uzaklığı (varsayılan: orta nokta)",
    "fresnel.opt.k": "Etkin dünya yarıçapı katsayısı (standart atmosfer 4/3)",
    "fresnel.bad_at": "nokta iki anten arasında olmalı",
    "fresnel.title": "Fresnel Bölgesi",
    "fresnel.point": "Nokta (d₁ / d₂)",
    "fresnel.r1": "1. Fresnel yarıçapı",
    "fresnel.r60": "%60 açıklık",
    "fresnel.bulge": "Dünya eğriliği",
    "fresnel.need": "Gereken açıklık",
    "fresnel.note": "Antenler arasındaki çizgi, o noktadaki engellerin bu kadar üstünden geçmeli.",

    # koaksiyel
    "coax.help": (
        "Bir frekansta koaksiyel kablo kaybı (tipik değerler).\n\n"
        "Kablolar: RG-58, RG-174, RG-316, RG-213, RG-6, LMR-195, LMR-240, LMR-400, LMR-600\n\n"
        "Örnekler:\n"
        "  elektro rf coax rg58 -f 868 -l 5\n"
        "  elektro rf coax lmr400 -f 2.4G -l 20m"
    ),
    "coax.arg": "Kablo tipi, örn: rg58, lmr400",
    "coax.opt.length": "Kablo uzunluğu (yalın sayı = m): 5, 150cm, 30ft",
    "coax.metavar.length": "UZUNLUK",
    "coax.unknown": "bilinmeyen kablo '{name}' (bilinenler: {options})",
    "coax.per100": "100 m başına kayıp",
    "coax.loss": "Toplam kayıp",
    "coax.delivered": "İletilen güç",
    "coax.delay": "Gecikme",
    "coax.electrical": "Elektriksel uzunluk",
    "coax.note": "Tipik değerlerdir; kablonun kendi datasheet'ine bak. Her konnektör ~0.1-0.3 dB ekler.",

    # MCU ortak
    "mcu.opt.clock": "Çevre birimi saati (Hz), örn: 16M, 72M",
    "mcu.opt.mcu": "Mikrodenetleyici ailesi: avr, stm32, generic",
    "mcu.unknown": "bilinmeyen MCU ailesi '{mcu}' (seçenekler: {options})",

    # UART
    "uart.help": (
        "UART baud hızı kaydı ve hatası.\n\n"
        "--baud verilmezse yaygın hızların tablosu gösterilir.\n\n"
        "Örnekler:\n"
        "  elektro uart -c 16M -b 115200\n"
        "  elektro uart -c 16M\n"
        "  elektro uart -c 72M -b 921600 -m stm32"
    ),
    "uart.opt.baud": "Baud hızı",
    "uart.opt.oversample": "--mcu generic için örnekleme katı",
    "uart.col.baud": "Baud",
    "uart.col.mode": "Mod",
    "uart.col.register": "Kayıt",
    "uart.col.actual": "Gerçek",
    "uart.col.error": "Hata",
    "uart.impossible": "mümkün değil",
    "uart.note": "±%2'ye kadar hata genelde çalışır; güvenilirlik için ±%1'in altında tut.",

    # PWM
    "pwm.help": (
        "Bir frekans için timer/PWM ön bölücüsü ve periyot kaydı.\n\n"
        "Örnekler:\n"
        "  elektro pwm -c 16M -f 20k                 (AVR Timer1)\n"
        "  elektro pwm -c 16M -f 1k --bits 8\n"
        "  elektro pwm -c 72M -f 20k -m stm32 -d 25"
    ),
    "pwm.opt.freq": "PWM frekansı (Hz)",
    "pwm.opt.bits": "Timer genişliği, bit (8, 16, 32)",
    "pwm.opt.duty": "Görev oranı % (karşılaştırma değerini hesaplar)",
    "pwm.bad": "saat ve frekans pozitif olmalı; bit 8, 10, 16 ya da 32 olmalı",
    "pwm.impossible": "bu frekans bu saat/timer ile üretilemez",
    "pwm.prescaler": "Ön bölücü",
    "pwm.actual": "Gerçek frekans",
    "pwm.error": "Hata",
    "pwm.resolution": "Çözünürlük",
    "pwm.steps": "adım",
    "pwm.compare": "{duty} için karşılaştırma değeri",
    "pwm.low_res": "Çözünürlük 8 bitin altında; frekansı düşür ya da saati yükselt.",

    # ADC
    "adc.help": (
        "ADC/DAC: LSB değeri, gerilim ↔ kod dönüşümü, ideal SNR.\n\n"
        "V = kod · Vref / 2ᴺ\n\n"
        "Örnekler:\n"
        "  elektro adc -b 12 --vref 3.3 --code 2048\n"
        "  elektro adc -b 10 --vref 5 --volt 1.2"
    ),
    "adc.opt.bits": "Çözünürlük (bit)",
    "adc.opt.vref": "Referans gerilimi (V)",
    "adc.opt.code": "Dijital kod → gerilim",
    "adc.opt.volt": "Gerilim → dijital kod",
    "adc.steps": "Adım",
    "adc.snr": "İdeal SNR",
    "adc.voltage_of": "{code} kodunun gerilimi",
    "adc.code_of": "{volt} için kod",
    "adc.code_range": "kod 0 ile {max} arasında olmalı",
    "adc.clipped": "Gerilim 0 … Vref dışında; kod kırpıldı.",
    "adc.note": "Bazı datasheet'ler bölen olarak 2ᴺ − 1 kullanır; fark 1 LSB'dir.",

    # I2C
    "i2c.help": (
        "Hat kapasitansı ve hıza göre I²C pull-up direnci aralığı.\n\n"
        "Rmin = (Vdd − 0.4 V) / Iol     Rmax = tr / (0.8473 · Cb)\n\n"
        "Örnekler:\n"
        "  elektro i2c --cb 200p\n"
        "  elektro i2c --vdd 5 --cb 100p -s 100k"
    ),
    "i2c.opt.vdd": "Pull-up besleme gerilimi (V)",
    "i2c.opt.cb": "Toplam hat kapasitansı (F), örn: 200p (cihaz başına ≈10 pF + kablo)",
    "i2c.opt.speed": "Hat hızı: 100k, 400k ya da 1M",
    "i2c.bad_speed": "hız 100k, 400k ya da 1M olmalı",
    "i2c.cb_limit": "I²C standardı en fazla 400 pF hat kapasitansına izin verir.",
    "i2c.impossible": "uygun direnç yok: bu hız için hat kapasitansı çok yüksek",
    "i2c.suggested": "Önerilen (E12)",
    "i2c.note": "Küçük R = daha hızlı kenarlar ama daha çok akım; Rmin ile Rmax arasında kal.",

    # CRC
    "crc.help": (
        "Bir bayt dizisinin CRC'si ve basit checksum'ları.\n\n"
        "Örnekler:\n"
        "  elektro crc \"01 03 00 00 00 0A\"\n"
        "  elektro crc 0x31323334 -a modbus\n"
        "  elektro crc \"123456789\" --text"
    ),
    "crc.arg": "Hex bayt olarak veri (\"01 03 0A\", 0x01030A) ya da --text ile metin",
    "crc.opt.text": "Veriyi metin olarak al (UTF-8)",
    "crc.opt.algo": "Sadece bu algoritma (örn: modbus, crc-32)",
    "crc.bad_hex": "geçersiz hex veri (iki haneli hex çiftleri kullan, örn: \"01 03 0A\")",
    "crc.unknown": "bilinmeyen algoritma '{algo}' (seçenekler: {options})",
    "crc.title": "{n} baytın CRC'si",
    "crc.col.algo": "Algoritma",
    "crc.col.bytes": "Baytlar (gönderim sırası)",

    # hesap makinesi
    "calc.help": (
        "Mühendislik gösterimini ve birimleri anlayan hesap makinesi.\n\n"
        "Operatörler: + − * / ^ ( )   Fonksiyonlar: sqrt log ln exp sin cos tan db dbp par\n"
        "Sabitler: pi e c.  par(a, b, …) = paralel eşdeğer.\n\n"
        "Örnekler:\n"
        "  elektro calc \"12V / (4k7 + 1k)\"\n"
        "  elektro calc \"1 / (2*pi*sqrt(10u * 100n))\" -u Hz\n"
        "  elektro calc \"par(1k, 2k2, 4k7)\" -u Ω\n"
        "  elektro calc \"db(3.3 / 0.1)\""
    ),
    "calc.arg": "İfade (kabukta tırnak içinde yaz)",
    "calc.opt.unit": "Sonuçla gösterilecek birim (V, A, Ω, Hz …)",
    "calc.syntax": "ifade anlaşılamadı",
    "calc.unknown_name": "bilinmeyen ad '{name}'",
    "calc.unsupported": "ifadede desteklenmeyen öğe",
    "calc.div_zero": "sıfıra bölme",
    "calc.complex": "sonuç karmaşık sayı",

    # birim
    "unit.help": (
        "Günlük elektronik işleri için birim dönüştürücü.\n\n"
        "Sıcaklık: c f k · Uzunluk: m cm mm um in mil ft · dB: db pratio vratio\n"
        "Kablo: awg mm2 · Bakır: oz · Açı: deg rad · Frekans: hz rpm\n\n"
        "Örnekler:\n"
        "  elektro unit 25 c\n"
        "  elektro unit 10 mil mm\n"
        "  elektro unit 6 db\n"
        "  elektro unit 22 awg"
    ),
    "unit.arg.value": "Değer",
    "unit.arg.src": "Kaynak birim ({units})",
    "unit.arg.dst": "Hedef birim (boşsa hepsi)",
    "unit.unknown": "bilinmeyen birim '{unit}' (seçenekler: {options})",
    "unit.no_path": "{src} → {dst} dönüşümü yok",
    "unit.below_zero": "mutlak sıfırın altında",
    "unit.power_ratio": "güç oranı",
    "unit.voltage_ratio": "gerilim oranı",
    "unit.period": "periyot (s)",

    # datasheet önbelleği
    "ds.opt.history": "Daha önce indirilen datasheet'leri listele (önbellek)",
    "ds.from_cache": "Önbellekte bulundu, indirmeye gerek yok.",
    "ds.cache_source": "önbellek",
    "ds.cache_empty": "Datasheet önbelleği boş.",
    "ds.cache_title": "İndirilen datasheet'ler",
    "ds.col.part": "Parça",
    "ds.col.size": "Boyut",
    "ds.col.date": "Tarih",
})

# --- 0.5 ---------------------------------------------------------------------------------
MESSAGES.update({
    "menu.opamp": "Op-amp yükselteçler",
    "menu.coil": "Hava nüveli bobin",
    "menu.crystal": "Kristal yük kondansatörü",
    "menu.rectifier": "Doğrultucu + filtre kondansatörü",
    "menu.acpower": "AC güç, güç faktörü düzeltme",
    "menu.shell": "Etkileşimli mod",
    "menu.vars": "Kayıtlı değişkenler",
    "menu.history": "Hesap geçmişi",

    # op-amp
    "op.help": "Op-amp yükselteçler: evirmeyen, eviren, fark ve toplayıcı.",
    "op.noninv.help": (
        "Evirmeyen yükselteç.  G = 1 + Rf / Rg\n\n"
        "--gain verilirse standart Rf/Rg çiftleri önerir; --rf ve --rg verilirse kazancı hesaplar.\n\n"
        "Örnekler:\n"
        "  elektro opamp noninv --gain 11\n"
        "  elektro opamp noninv --rf 100k --rg 10k --vin 0.2 --gbw 1M"
    ),
    "op.inv.help": (
        "Eviren yükselteç.  G = −Rf / Rin\n\n"
        "Örnekler:\n"
        "  elektro opamp inv --gain 10\n"
        "  elektro opamp inv --rf 47k --rin 4k7 --vin 0.5 --vcc 12"
    ),
    "op.diff.help": (
        "Fark yükselteci (R1 = R3, R2 = R4).  Vout = (R2/R1) · (V+ − V−)\n\n"
        "Örnek:\n"
        "  elektro opamp diff --gain 5"
    ),
    "op.sum.help": (
        "Eviren toplayıcı.  Vout = −Rf · Σ(Vi / Ri)\n\n"
        "Örnek:\n"
        "  elektro opamp sum --rf 10k --rin 10k --vin 1 --rin 20k --vin 0.5"
    ),
    "op.opt.gain": "Hedef kazanç (V/V)",
    "op.opt.gain_inv": "Hedef kazancın büyüklüğü (işaret her zaman negatif)",
    "op.opt.rf": "Geri besleme direnci Rf",
    "op.opt.rg": "Toprağa giden direnç Rg",
    "op.opt.rin": "Giriş direnci Rin",
    "op.opt.vin": "Giriş gerilimi (çıkışı hesaplar)",
    "op.opt.vcc": "Besleme gerilimi (çıkış kırpılıyorsa uyarır)",
    "op.opt.gbw": "Op-amp'ın kazanç-bant genişliği çarpımı (Hz), örn: 1M",
    "op.need": "--gain ya da iki direncin ikisini de ver",
    "op.noninv.min": "evirmeyen yükseltecin kazancı 1'den küçük olamaz",
    "op.follower": "gerilim izleyici: çıkışı doğrudan − girişe bağla",
    "op.pairs": "Standart direnç çiftleri",
    "op.gain": "Kazanç",
    "op.col.error": "Hata",
    "op.bandwidth": "Bant genişliği (−3 dB)",
    "op.zin": "Giriş empedansı",
    "op.note": "Not",
    "op.clip": "Çıkış {vout} beslemeyi ({vcc}) aşıyor; kırpılacak.",
    "op.noninv.title": "Evirmeyen Yükselteç",
    "op.inv.title": "Eviren Yükselteç",
    "op.sum.title": "Toplayıcı Yükselteç",
    "op.noninv.note": "Düşük ofset için Rf ∥ Rg ≈ kaynak direnci olsun; 1k-100k değerleri tipiktir.",
    "op.inv.note": "Giriş empedansı Rin'e eşittir; kaynağa göre yeterince büyük seç.",
    "op.diff.note": "Ortak mod bastırmayı direnç eşleşmesi belirler; mümkünse %0.1 direnç kullan.",
    "op.sum.opt.rin": "Giriş direnci (her giriş için bir kez yaz)",
    "op.sum.opt.vin": "Giriş gerilimi (her giriş için bir kez, aynı sırayla)",
    "op.sum.mismatch": "--rin ve --vin sayısı aynı olmalı",

    # sadeleştirme
    "dig.simp.help": (
        "Boolean fonksiyonu en sade çarpımlar toplamına indirir (Quine-McCluskey).\n\n"
        "2-4 değişkende Karnaugh haritasını da gösterir.\n\n"
        "Örnekler:\n"
        "  elektro logic simplify \"A&B | A&~B\"\n"
        "  elektro logic simplify -m 0,1,2,5,6,7 -v A,B,C\n"
        "  elektro logic simplify -m 1,3,7,11,15 -d 0,2,5"
    ),
    "dig.simp.arg": "Boolean ifade (ya da --minterms kullan)",
    "dig.simp.opt.minterms": "Minterm listesi, örn: 0,2,5,7",
    "dig.simp.opt.dontcare": "Önemsiz (don't care) terimler, örn: 1,3",
    "dig.simp.opt.vars": "Değişken adları, örn: A,B,C,D (en anlamlı bit önce)",
    "dig.simp.need": "bir ifade ya da --minterms ver",
    "dig.simp.bad_list": "liste virgülle ayrılmış tam sayılardan oluşmalı",
    "dig.simp.few_vars": "bu mintermler için en az {n} değişken gerekli",
    "dig.simp.too_many": "en fazla 8 değişken destekleniyor",
    "dig.simp.title": "Sadeleştirilmiş",
    "dig.simp.minterms": "Fonksiyon",
    "dig.simp.result": "En sade SOP",
    "dig.simp.code": "İfade olarak",
    "dig.simp.cost": "Maliyet",
    "dig.simp.cost_val": "{terms} terim, {lits} literal",

    # doğrultucu
    "rect.help": (
        "Trafo + doğrultucu + filtre kondansatörü.\n\n"
        "ΔV = I / (k · f · C)   (k = 2 tam dalga, 1 yarım dalga)\n\n"
        "Örnekler:\n"
        "  elektro rectifier --vac 12 -i 1 --ripple 1\n"
        "  elektro rectifier --vac 9 -i 500m --c 2200u --vmains 230\n"
        "  elektro rectifier --vac 15 --type half -i 100m --ripple 0.5"
    ),
    "rect.opt.vac": "Sekonder gerilimi (V RMS)",
    "rect.opt.type": "Doğrultucu: bridge (köprü), center (orta uçlu), half (yarım dalga)",
    "rect.opt.freq": "Şebeke frekansı (Hz)",
    "rect.opt.iload": "Yük akımı (A)",
    "rect.opt.ripple": "İzin verilen dalgalanma (V tepe-tepe) — C'yi hesaplar",
    "rect.opt.c": "Filtre kondansatörü — dalgalanmayı hesaplar",
    "rect.opt.vdiode": "Diyot başına ileri gerilim (V)",
    "rect.opt.vmains": "Primer gerilimi (V RMS) — sarım oranını hesaplar",
    "rect.bad_type": "doğrultucu tipi şunlardan biri olmalı: {options}",
    "rect.too_low": "sekonder gerilimi diyot düşümlerinden küçük",
    "rect.title": "Doğrultucu",
    "rect.type": "Tip",
    "rect.kind.bridge": "tam dalga köprü",
    "rect.kind.center": "tam dalga orta uçlu",
    "rect.kind.half": "yarım dalga",
    "rect.vpeak": "Tepe DC (yüksüz)",
    "rect.piv": "Diyot ters gerilimi (PIV)",
    "rect.ripple_freq": "Dalgalanma frekansı",
    "rect.c": "Kondansatör",
    "rect.ripple": "Dalgalanma (t-t)",
    "rect.cap_voltage": "Kondansatör gerilim değeri",
    "rect.ratio": "Sarım oranı",
    "rect.diode_i": "Diyot başına akım",
    "rect.hint": "Filtre kondansatörü için -i ve --ripple (ya da --c) ekle.",
    "rect.note": "Kondansatörün dalgalanma akımı yüksektir; buna uygun, düşük ESR'li bir tip seç.",

    # AC güç
    "ac.help": (
        "Tek ya da üç fazlı AC güç ve güç faktörü düzeltme.\n\n"
        "P = V·I·cosφ (tek faz)   P = √3·V·I·cosφ (3 faz, V fazlar arası)\n\n"
        "Örnekler:\n"
        "  elektro acpower --v 230 --i 10 --pf 0.8\n"
        "  elektro acpower --v 400 --p 15k --pf 0.82 --phases 3\n"
        "  elektro acpower --i 10 --pf 0.75 --target-pf 0.95"
    ),
    "ac.opt.v": "Gerilim (V RMS; 3 fazda fazlar arası)",
    "ac.opt.i": "Akım (A RMS)",
    "ac.opt.p": "Aktif güç (W) — akımı hesaplar",
    "ac.opt.pf": "Güç faktörü cosφ",
    "ac.opt.phases": "Faz sayısı: 1 ya da 3",
    "ac.opt.target": "Hedef güç faktörü — kompanzasyon kondansatörünü hesaplar",
    "ac.bad_phases": "faz sayısı 1 ya da 3 olmalı",
    "ac.bad_pf": "gerilim pozitif ve 0 < cosφ ≤ 1 olmalı",
    "ac.bad_target": "hedef güç faktörü mevcut değerden büyük ve en fazla 1 olmalı",
    "ac.need": "--i ya da --p ver",
    "ac.title": "AC Güç",
    "ac.system": "Sistem",
    "ac.single": "tek faz",
    "ac.three": "üç faz",
    "ac.current": "Akım",
    "ac.p": "Aktif güç P",
    "ac.q": "Reaktif güç Q",
    "ac.s": "Görünür güç S",
    "ac.qc": "Kompanzasyon Qc",
    "ac.cap": "Kompanzasyon kondansatörü",
    "ac.cap_delta": "Faz başına kondansatör (Δ)",
    "ac.new_current": "Kompanzasyon sonrası akım",
    "ac.three_note": "Yıldız bağlı kondansatör grubu için kapasitansı 3 ile çarp.",

    # yıldız-üçgen
    "sd.help": (
        "Üç direnç/empedans için yıldız (Y) ↔ üçgen (Δ) dönüşümü.\n\n"
        "Örnekler:\n"
        "  elektro stardelta delta 10 20 30     (Rab Rbc Rca → Ra Rb Rc)\n"
        "  elektro stardelta star 5 10 15       (Ra Rb Rc → Rab Rbc Rca)"
    ),
    "sd.arg.mode": "Verdiğin bağlantı: delta ya da star",
    "sd.arg.values": "Üç değer: Rab Rbc Rca (delta) ya da Ra Rb Rc (star)",
    "sd.bad": "kullanım: stardelta delta|star R1 R2 R3",
    "sd.note": "Ra, A düğümündeki direnç; Rab, A ile B arasındaki direnç.",

    # bobin
    "coil.help": (
        "Tek katlı hava nüveli bobin (Wheeler formülü).\n\n"
        "Örnekler:\n"
        "  elektro coil --l 1u --d 10               (10 mm gövdede 1 µH için sarım)\n"
        "  elektro coil --l 330n --d 6 --wire 0.8\n"
        "  elektro coil --n 12 --d 8 --length 15"
    ),
    "coil.opt.l": "Hedef endüktans (H), örn: 1u",
    "coil.opt.n": "Sarım sayısı — L'yi hesaplar",
    "coil.opt.d": "Bobin gövdesi çapı (mm)",
    "coil.opt.wire": "Tel çapı (mm)",
    "coil.opt.length": "Sargı uzunluğu (mm); varsayılan: sık sarım",
    "coil.need": "--l ya da --n'den birini ver",
    "coil.title": "Hava Nüveli Bobin",
    "coil.turns": "Sarım",
    "coil.inductance": "Endüktans",
    "coil.length": "Sargı uzunluğu",
    "coil.mean_d": "Ortalama çap",
    "coil.wire_len": "Tel uzunluğu",
    "coil.short": "Bobin çapına göre çok kısa; formül daha az isabetli.",
    "coil.note": "Wheeler formülü uzunluk > 0.8 × yarıçap için ~%1 isabetlidir. Bacaklar için fazladan tel bırak.",

    # kristal
    "xtal.help": (
        "Kristal osilatör (Pierce) için yük kondansatörleri.\n\n"
        "C1 = C2 = 2 · (CL − Cparazit)\n\n"
        "Örnekler:\n"
        "  elektro crystal --cl 12p\n"
        "  elektro crystal --cl 18p --cstray 3p\n"
        "  elektro crystal --c 22p                  (22 pF hangi CL'yi verir?)"
    ),
    "xtal.opt.cl": "Kristal datasheet'indeki yük kapasitansı (F)",
    "xtal.opt.cstray": "Bacak ve yolların parazitik kapasitansı (F), tipik 2-5p",
    "xtal.opt.c": "Mevcut kondansatör değeri — CL'yi hesaplar",
    "xtal.need": "--cl ya da --c'den birini ver",
    "xtal.too_small": "CL parazitik kapasitanstan küçük; kondansatör gerekmez (ya da Cstray'i kontrol et)",
    "xtal.title": "Kristal Yük Kondansatörleri",
    "xtal.standard": "Standart (E12)",
    "xtal.note": "Fazla kapasitans frekansı düşürür ve osilatörü durdurabilir.",

    # grafik
    "plot.opt": "Grafik kaydet: .svg (dahili), .png / .pdf (matplotlib gerekir)",
    "plot.saved": "Grafik kaydedildi: {path}",
    "plot.bad_suffix": "grafik dosyası .svg, .png ya da .pdf ile bitmeli",
    "plot.need_mpl": "PNG/PDF için matplotlib gerekli: {pip}   (ya da .svg kullan)",
    "plot.freq": "Frekans",
    "plot.time": "Zaman",
    "plot.voltage": "Gerilim (V)",
    "plot.current": "Akım (A)",
    "plot.metavar": "DOSYA",

    "calc.var_not_number": "'{name}' değişkeni bir sayı değil",

    # değişkenler
    "vars.help": (
        "Kayıtlı değişkenleri listele.\n\n"
        "Değişkenler her komutta @isim olarak kullanılır:\n"
        "  elektro set vin 12\n"
        "  elektro ohm -v @vin -r 1k\n"
        "  elektro calc \"vin / 2\"\n\n"
        "--local ile ./.elektro.json'a (projeye özel; üst klasörlerde de aranır) kaydedilir."
    ),
    "vars.set.help": "Değişken kaydet: elektro set İSİM DEĞER (@İSİM olarak kullan).",
    "vars.unset.help": "Değişkeni sil.",
    "vars.arg.name": "Değişken adı (harf, rakam, _)",
    "vars.arg.value": "Değer, örn: 12, 4k7, 100n",
    "vars.opt.local": "Bu proje için ./.elektro.json'a kaydet",
    "vars.bad_name": "geçersiz değişken adı '{name}'",
    "vars.unknown": "bilinmeyen değişken @{name} (bkz: elektro vars)",
    "vars.removed": "silindi",
    "vars.empty": "Henüz değişken yok. Örnek: elektro set vin 12",
    "vars.col.name": "Ad",
    "vars.col.value": "Değer",
    "vars.col.scope": "Kapsam",
    "vars.global": "genel",
    "vars.local": "proje",
    "vars.overridden": "üzerine yazıldı",

    # geçmiş
    "hist.help": (
        "Hesap geçmişi.\n\n"
        "Örnekler:\n"
        "  elektro history\n"
        "  elektro history -s filter\n"
        "  elektro history --run 12\n"
        "  elektro history --clear"
    ),
    "hist.opt.n": "Gösterilecek kayıt sayısı",
    "hist.opt.search": "Sadece bu metni içeren kayıtlar",
    "hist.opt.run": "Bu numaralı kaydı tekrar çalıştır",
    "hist.opt.clear": "Tüm geçmişi sil",
    "hist.bad_id": "bu numarada kayıt yok (1 … {max})",
    "hist.cleared": "Geçmiş silindi.",
    "hist.empty": "Geçmiş boş.",
    "hist.col.command": "Komut",
    "hist.rerun": "Tekrar çalıştır: elektro history --run NUMARA",

    # kabuk
    "shell.help": (
        "Etkileşimli mod: komutları 'elektro' yazmadan gir.\n\n"
        "Tab komutları tamamlar, ↑/↓ önceki satırlarda gezer.\n"
        "Yerleşik: help, clear, exit"
    ),
    "shell.welcome": "etkileşimli mod. Komutlar için 'help', çıkmak için 'exit' yaz.",
})

# --- 0.6 ---------------------------------------------------------------------------------
MESSAGES.update({
    # rapor çıktısı
    "cli.opt.md": "Sonucu Markdown olarak yaz (not ve raporlar için tablolar)",
    "cli.opt.latex": "Sonucu LaTeX olarak yaz",
    "cli.opt.report": "Sonucu bir rapor dosyasına ekle (.md veya .tex)",
    "cli.opt.copy": "Çıktıyı panoya kopyala",
    "report.conflict": "--md, --latex/--report ve --json birlikte kullanılamaz",
    "report.quantity": "Büyüklük",
    "report.value": "Değer",
    "report.appended": "Rapora eklendi: {path}",
    "report.copied": "Panoya kopyalandı.",
    "report.no_clipboard": "pano aracı bulunamadı (wl-clipboard veya xclip kur)",

    # calc: karmaşık sayılar
    "calc.opt.freq": "Frekans (Hz) — karmaşık empedansı R + L veya R + C olarak gösterir",
    "calc.need_real": "{name}() gerçel sayı ister",
    "calc.rect": "Kartezyen",
    "calc.polar": "Kutupsal",
    "calc.mag": "Genlik",
    "calc.angle": "Açı",
    "calc.eq_r": "Seri R @ {f}",
    "calc.eq_l": "Seri L",
    "calc.eq_c": "Seri C",
    "calc.help": (
        "Mühendislik gösterimini, birimleri ve karmaşık sayıları anlayan hesap makinesi.\n\n"
        "İşleçler: + − * / ^ ( )  ||  (paralel)   Fonksiyonlar: sqrt log ln exp sin cos tan db dbp par\n"
        "Karmaşık: j, 3+j4, 10∠30 (derece), polar(r, derece), re im abs arg conj\n"
        "Empedans: zl(L, f) = jωL, zc(C, f) = 1/(jωC).  Sabitler: pi e c\n\n"
        "Örnekler:\n"
        "  elektro calc \"12V / (4k7 + 1k)\"\n"
        "  elektro calc \"par(1k, 2k2, 4k7)\" -u Ω\n"
        "  elektro calc \"230∠0 / (10 + zl(100m, 50))\" -u A\n"
        "  elektro calc \"100 + zl(10m, 1k) || zc(1u, 1k)\" -u Ω -f 1k"
    ),

    # paneller / menü
    "panel.install": "Tesisat ve makineler",
    "menu.cable": "Kablo kesiti",
    "menu.breaker": "Sigorta / otomatik sigorta",
    "menu.shortcircuit": "Kısa devre akımı",
    "menu.transformer": "Transformatör",
    "menu.motor": "Asenkron motor",
    "menu.wave": "RMS, ortalama, tepe faktörü",
    "menu.fft": "CSV spektrumu (THD)",
    "menu.pinout": "Entegre / transistör bacakları",
    "menu.report": "Markdown / LaTeX rapor",

    # kablo
    "cable.help": (
        "Alçak gerilim kablo kesitini akım taşıma kapasitesi ve gerilim düşümüne göre seçer (IEC 60364-5-52).\n\n"
        "Döşeme şekilleri: A1 (yalıtımlı duvarda boru içinde), B1 (duvar üstünde/içinde boru içinde),\n"
        "C (doğrudan duvara kroşeli), D (toprak altında).\n\n"
        "Örnekler:\n"
        "  elektro cable -i 16 -l 25\n"
        "  elektro cable -p 9k --phases 3 --pf 0.85 -l 40 --method C\n"
        "  elektro cable -i 120 --phases 3 -l 80 --material al --insulation xlpe --group 3\n"
        "  elektro cable -i 20 -l 30 --mm2 2.5          (verilen kesiti kontrol et)"
    ),
    "cable.opt.current": "Yük akımı Ib (A)",
    "cable.opt.power": "Yük gücü (W) — akımı hesaplar",
    "cable.opt.v": "Gerilim (V); varsayılan 230 (tek faz) / 400 (üç faz)",
    "cable.opt.length": "Kablo uzunluğu (tek yön), ör. 25 (m), 120m",
    "cable.opt.drop": "İzin verilen gerilim düşümü (%)",
    "cable.opt.method": "Döşeme şekli: A1, B1, C, D",
    "cable.opt.material": "İletken: cu (bakır) veya al (alüminyum)",
    "cable.opt.insulation": "Yalıtım: pvc (70 °C) veya xlpe (90 °C)",
    "cable.opt.ta": "Ortam sıcaklığı (°C); varsayılan havada 30, toprakta 20",
    "cable.opt.group": "Birlikte döşenen devre sayısı (gruplama katsayısı)",
    "cable.opt.mm2": "Seçmek yerine bu kesiti (mm²) kontrol et",
    "cable.bad_choice": "geçersiz değer '{value}' (seçenekler: {options})",
    "cable.too_hot": "ortam sıcaklığı {tmax} °C'nin altında olmalı",
    "cable.need": "akımı (-i) veya gücü (-p) ver",
    "cable.bad_section": "standart bir kesit değil (seçenekler: {options})",
    "cable.none": "300 mm² bile yetmiyor; paralel kablo veya daha yüksek gerilim kullan",
    "cable.title": "Kablo Seçimi",
    "cable.system": "Sistem",
    "cable.ib": "Yük akımı Ib",
    "cable.section": "Kesit",
    "cable.iz": "Akım taşıma kapasitesi Iz",
    "cable.drop": "Gerilim düşümü",
    "cable.loss": "Kablo kaybı",
    "cable.temp": "İletken sıcaklığı",
    "cable.by_ampacity": "Yalnız kapasiteye göre",
    "cable.mcb": "Uygun sigorta (Ib ≤ In ≤ Iz)",
    "cable.no_mcb": "yok — daha kalın kablo seç",
    "cable.not_ok": "bu kesit koşulları sağlamıyor",
    "cable.note1": "Kapasiteler: IEC 60364-5-52 (bakır/PVC); XLPE ve alüminyum için yaklaşık katsayılar.",
    "cable.note2": "İç Tesisat Yönetmeliği: aydınlatmada %1.5, kuvvette %3 (IEC tipik: %3 / %5).",

    # sigorta
    "brk.help": (
        "Otomatik sigorta (MCB) veya gG buşonlu sigorta seçer ve kablo korumasını kontrol eder.\n\n"
        "Koşullar: Ib ≤ In ≤ Iz ve I2 ≤ 1.45·Iz.  Arızada açma: Zs ≤ U0 / Ia.\n\n"
        "Örnekler:\n"
        "  elektro breaker -i 14 --iz 21\n"
        "  elektro breaker -i 14 --iz 21 --curve B --mm2 2.5 -l 30\n"
        "  elektro breaker -i 40 --iz 50 --type fuse"
    ),
    "brk.opt.current": "Yük akımı Ib (A)",
    "brk.opt.iz": "Kablonun akım taşıma kapasitesi Iz (A) — bkz: elektro cable",
    "brk.opt.type": "Cihaz: mcb veya fuse (gG)",
    "brk.opt.curve": "MCB eğrisi: B, C veya D",
    "brk.opt.zs": "Ölçülen toprak arıza çevrim empedansı Zs (Ω)",
    "brk.opt.mm2": "Kablo kesiti (mm²) — Zs'yi ve en büyük uzunluğu hesaplar",
    "brk.opt.length": "Kablo uzunluğu (m) — Zs'yi hesaplar",
    "brk.opt.ze": "Zs hesabı için dış çevrim empedansı Ze (Ω)",
    "brk.opt.u0": "Faz-toprak gerilimi U0 (V)",
    "brk.too_big": "akım en büyük standart değerin üzerinde",
    "brk.title": "Koruma Cihazı",
    "brk.device": "Cihaz",
    "brk.magnetic": "Ani açma (manyetik)",
    "brk.zs_max": "En büyük çevrim empedansı Zs",
    "brk.zs_calc": "Çevrim empedansı Zs (hesap)",
    "brk.ik_min": "Toprak arıza akımı",
    "brk.lmax": "En büyük uzunluk ({mm2} mm²)",
    "brk.not_ok": "kablo korunmuyor; en fazla {max} A kullan veya kabloyu büyüt",
    "brk.no_device": "bu yük akımında kabloyu koruyan standart bir cihaz yok",
    "brk.note.curve": "B: omik yükler, aydınlatma · C: genel, motorlar · D: trafolar, yüksek kalkış akımı.",
    "brk.note.zs": "Kablodan Zs hesabında Ze = {ze} Ω ve faz kesitine eşit koruma iletkeni alındı.",
    "brk.note.fuse": "gG sigorta: I2 = 1.6·In (In ≥ 16 A); açma süresini sigorta eğrisinden kontrol et.",

    # kısa devre
    "sc.help": (
        "Trafodan beslenen alçak gerilim şebekesinde kısa devre akımı (IEC 60909, basitleştirilmiş).\n\n"
        "Örnekler:\n"
        "  elektro shortcircuit --kva 630\n"
        "  elektro shortcircuit --kva 1000 --uk 6 --pk 10.5k --mm2 240 -l 60 --parallel 2\n"
        "  elektro shortcircuit --kva 400 --mm2 16 -l 80 --time 0.4"
    ),
    "sc.opt.kva": "Trafo gücü (kVA)",
    "sc.opt.uk": "Kısa devre gerilimi uk (%); varsayılan 4 (≤ 630 kVA) veya 6",
    "sc.opt.v": "Sekonder hat gerilimi (V)",
    "sc.opt.pk": "Bakır (yük) kayıpları Pk (W); varsayılan ur = %1",
    "sc.opt.sk": "Üst şebeke kısa devre gücü Sk'' (MVA); 0 = sonsuz",
    "sc.opt.mm2": "Arıza noktasına kadar kablo kesiti (mm²)",
    "sc.opt.length": "Arıza noktasına kadar kablo uzunluğu (m)",
    "sc.opt.parallel": "Paralel kablo sayısı",
    "sc.opt.time": "Açma süresi (s) — kablonun ısıl dayanımını kontrol eder",
    "sc.need_cable": "--mm2 ve --length birlikte verilmeli",
    "sc.bad_pk": "bakır kayıpları bu uk için çok yüksek",
    "sc.title": "Kısa Devre Akımı",
    "sc.trafo": "Transformatör",
    "sc.in": "Anma akımı",
    "sc.zq": "Şebeke Zq ({sk} MVA)",
    "sc.zc": "Kablo Zc ({cable})",
    "sc.icu": "Kesme kapasitesi",
    "sc.smin": "En küçük kesit ({t}, k = {k})",
    "sc.note1": "Ik3 en büyük: c = 1.05, iletkenler 20 °C; Ik1 en küçük (faz–nötr): c = 0.95.",
    "sc.note2": "Kesme kapasitesi için Ik3'ü, korumanın açtığını kontrol için Ik1'i kullan.",

    # transformatör
    "tr.help": (
        "Transformatör: dönüştürme oranı, akımlar ve küçük şebeke trafosunun sargı bilgileri.\n\n"
        "Örnekler:\n"
        "  elektro transformer --v1 230 --v2 12\n"
        "  elektro transformer --v1 230 --v2 24 --va 100\n"
        "  elektro transformer --v1 34.5k --v2 400 --va 630k --phases 3"
    ),
    "tr.opt.v1": "Primer gerilim (V)",
    "tr.opt.v2": "Sekonder gerilim (V, yükte)",
    "tr.opt.va": "Anma gücü (VA), ör. 50, 1k, 630k",
    "tr.opt.b": "Tepe akı yoğunluğu (T): silisli sac için 1.0–1.4",
    "tr.opt.j": "Akım yoğunluğu (A/mm²): 2–3.5",
    "tr.opt.eff": "Verim",
    "tr.opt.area": "Nüve kesiti (cm²); varsayılan ≈ √P",
    "tr.opt.reg": "Yükteki gerilim düşümü için sekondere eklenen sarım (%)",
    "tr.title": "Transformatör",
    "tr.ratio": "Dönüştürme oranı",
    "tr.kind": "Tür",
    "tr.step_down": "düşürücü",
    "tr.step_up": "yükseltici",
    "tr.hint": "Akımlar ve sargı bilgileri için --va ekle.",
    "tr.power": "Güç",
    "tr.three_note": "Akımlar hat akımlarıdır. Sargı tasarımı yalnızca tek fazlı trafolar için hesaplanır.",
    "tr.area": "Nüve kesiti",
    "tr.tpv": "Volt başına sarım",
    "tr.wire1": "Primer teli",
    "tr.wire2": "Sekonder teli",
    "tr.big": "Pratik formüller küçük trafolar içindir (birkaç yüz VA'ya kadar).",
    "tr.note1": "B = {b} T ve J = {j} A/mm² ile hesaplandı; pencere iki sargıyı da almalı.",
    "tr.note2": "N/V = 1 / (4.44 · f · B · A).  B çok yüksekse nüve ısınır ve boşta akım büyür.",

    # motor
    "mot.help": (
        "Asenkron motor: akım, moment, kayma, kayıplar ve kalkış akımı.\n\n"
        "Örnekler:\n"
        "  elektro motor -p 7.5k --rpm 1450\n"
        "  elektro motor -p 15k --pf 0.86 --eff 0.92 --poles 2 --rpm 2940\n"
        "  elektro motor -p 750 --v 230 --phases 1 --pf 0.75 --eff 0.7"
    ),
    "mot.opt.power": "Anma (mil) gücü (W), ör. 7.5k",
    "mot.opt.v": "Gerilim (V; üç fazda hat gerilimi)",
    "mot.opt.eff": "Verim",
    "mot.opt.poles": "Kutup sayısı (2, 4, 6 …)",
    "mot.opt.rpm": "Etiketteki anma devri (d/dk)",
    "mot.opt.start": "Kalkış akımı / anma akımı (direkt yol verme)",
    "mot.bad_poles": "kutup sayısı çift ve en az 2 olmalı",
    "mot.bad_rpm": "devir 0 ile senkron devir ({ns} d/dk) arasında olmalı",
    "mot.title": "Asenkron Motor",
    "mot.power": "Çıkış gücü",
    "mot.ns": "Senkron devir",
    "mot.poles": "kutup",
    "mot.speed": "Anma devri",
    "mot.assumed": "%4 kayma varsayıldı",
    "mot.slip": "Kayma",
    "mot.torque": "Anma momenti",
    "mot.pin": "Giriş gücü",
    "mot.losses": "Kayıplar",
    "mot.current": "Anma akımı",
    "mot.start_dol": "Kalkış akımı (direkt)",
    "mot.start_yd": "Kalkış akımı (Y-Δ)",
    "mot.note1": "Kabloyu anma akımına, korumayı kalkış akımına göre seç (C/D eğrisi).",
    "mot.note2": "Yıldız-üçgen yol verme kalkış akımını ve momentini 1/3'e düşürür.",
    "mot.note_single": "Tek fazlı motorlar daimi (çoğu zaman bir de kalkış) kondansatörü ister.",

    # dalga şekli
    "wave.help": (
        "Bir dalga şeklinin RMS, ortalama, doğrultulmuş ortalama, tepe ve biçim faktörü.\n\n"
        "Şekiller: sine, square, triangle, sawtooth, pwm (0…Vp), halfwave, fullwave (doğrultulmuş sinüs)\n\n"
        "Örnekler:\n"
        "  elektro wave sine --vp 325\n"
        "  elektro wave sine --rms 230\n"
        "  elektro wave pwm --vp 12 -d 25 -r 10\n"
        "  elektro wave square --vpp 5 --offset 2.5 -f 1k --plot kare.svg"
    ),
    "wave.arg": "Dalga şekli",
    "wave.opt.vp": "Tepe genliği",
    "wave.opt.vpp": "Tepeden tepeye değer",
    "wave.opt.rms": "RMS değer (ofsetsiz) — genliği hesaplar",
    "wave.opt.offset": "DC ofset",
    "wave.opt.duty": "Doluluk oranı (%), pwm ve square için",
    "wave.opt.freq": "Frekans (Hz) — periyodu gösterir",
    "wave.opt.load": "Yük direnci (Ω) — gücü hesaplar",
    "wave.opt.unit": "Değerlerin birimi (V, A …)",
    "wave.bad_shape": "bilinmeyen dalga şekli (seçenekler: {options})",
    "wave.need": "--vp, --vpp veya --rms'den tam olarak birini ver",
    "wave.bad": "doluluk oranı %0 ile %100 arasında, frekans ve yük pozitif olmalı",
    "wave.title": "Dalga Şekli",
    "wave.shape": "Şekil",
    "wave.kind.sine": "sinüs",
    "wave.kind.square": "kare",
    "wave.kind.triangle": "üçgen",
    "wave.kind.sawtooth": "testere dişi",
    "wave.kind.pwm": "PWM",
    "wave.kind.halfwave": "yarım dalga doğrultulmuş sinüs",
    "wave.kind.fullwave": "tam dalga doğrultulmuş sinüs",
    "wave.peak": "En büyük / en küçük",
    "wave.vpp": "Tepeden tepeye",
    "wave.dc": "Ortalama (DC)",
    "wave.rms": "RMS (gerçek)",
    "wave.ac_rms": "RMS (yalnız AC)",
    "wave.rect": "Doğrultulmuş ortalama",
    "wave.crest": "Tepe faktörü",
    "wave.form": "Biçim faktörü",
    "wave.period": "Periyot",
    "wave.t_high": "Yüksek süre",
    "wave.power": "{r} üzerindeki güç",
    "wave.note1": "RMS = √(DC² + AC_rms²).  Ortalama ölçen multimetreler 1.111 × doğrultulmuş ortalama gösterir.",
    "wave.note2": "Bu ölçü aletleri yalnız sinüste doğrudur; diğer şekiller için true-RMS ölçü aleti kullan.",

    # fft
    "fft.help": (
        "CSV dosyasındaki örneklenmiş sinyalin spektrumu (osiloskop veya veri kaydedici çıktısı).\n\n"
        "Temel frekansı, en büyük tepeleri, THD ve THD+N'yi bulur. Örnekleme hızı zaman sütunundan,\n"
        "'Increment' başlığından (Rigol) veya --rate'ten alınır.\n\n"
        "Örnekler:\n"
        "  elektro fft osiloskop.csv\n"
        "  elektro fft veri.csv --column 3 --window flattop\n"
        "  elektro fft adc.txt --rate 48k --plot spektrum.svg"
    ),
    "fft.arg": "Sayısal sütunlar içeren CSV / metin dosyası",
    "fft.opt.column": "Sinyalin sütunu (1 = ilk); zaman sütunu varsa varsayılan 2",
    "fft.opt.rate": "Zaman sütunu yoksa örnekleme hızı (Hz)",
    "fft.opt.window": "Pencere: {options}",
    "fft.opt.peaks": "Listelenecek tepe sayısı",
    "fft.no_data": "dosyada sayısal veri bulunamadı",
    "fft.too_short": "en az 16 örnek gerekli",
    "fft.bad_window": "bilinmeyen pencere (seçenekler: {options})",
    "fft.bad_column": "sütun 1 ile {n} arasında olmalı",
    "fft.src.rate": "--rate",
    "fft.src.header": "dosya başlığı",
    "fft.src.time": "zaman sütunu",
    "fft.need_rate": "örnekleme hızı bilinmiyor; --rate ver",
    "fft.index_col": "ilk sütun örnek numarasına benziyor (adım 1); zaman değilse --rate ver",
    "fft.title": "Spektrum (FFT)",
    "fft.file": "Dosya",
    "fft.fs": "Örnekleme hızı",
    "fft.samples": "Örnek",
    "fft.resolution": "Çözünürlük",
    "fft.fundamental": "Temel bileşen",
    "fft.peaks": "En büyük tepeler",
    "fft.amp": "Genlik",
    "fft.note": "Pencere: {window}. Genlikler tepe değeridir; dBc temel bileşene göredir.",

    # pinout
    "pin.help": (
        "Yaygın entegre ve transistörlerin bacak bağlantıları (çevrimdışı).\n\n"
        "Örnekler:\n"
        "  elektro pinout              (parça listesi)\n"
        "  elektro pinout ne555\n"
        "  elektro pinout 74hc595\n"
        "  elektro pinout bc547"
    ),
    "pin.arg": "Parça adı, ör. ne555, lm358, 7805",
    "pin.tab": "tabla",
    "pin.col.part": "Parça",
    "pin.col.package": "Kılıf",
    "pin.col.desc": "Açıklama",
    "pin.col.aliases": "Aynı bacak düzeni",
    "pin.usage": "Birini göster: elektro pinout AD",
    "pin.unknown": "'{name}' listede yok (bkz: elektro pinout). Dene: elektro datasheet {name}",
    "pin.note.dip": "Üstten görünüş; 1. bacak çentik / nokta yanındadır, numaralar saat yönünün tersine artar.",
    "pin.note.front": "Önden görünüş (yazılı yüz sana dönük, bacaklar aşağıda). Üreticiler farklı olabilir — datasheet'e bak.",
    "pin.same": "Aynı bacak düzeni: {parts}",
    "pin.desc.ne555": "Zamanlayıcı",
    "pin.desc.lm358": "Çift op-amp",
    "pin.desc.ua741": "Tekli op-amp",
    "pin.desc.lm386": "Ses güç yükselteci",
    "pin.desc.attiny85": "8 bit AVR mikrodenetleyici",
    "pin.desc.pc817": "Optokuplör",
    "pin.desc.74hc00": "Dörtlü 2 girişli NAND kapısı",
    "pin.desc.74hc04": "Altılı DEĞİL kapısı",
    "pin.desc.74hc595": "Çıkış tutuculu 8 bit kaydırmalı kaydedici",
    "pin.desc.cd4017": "Onluk sayıcı / bölücü",
    "pin.desc.l293d": "Çift H-köprü motor sürücü",
    "pin.desc.atmega328p": "8 bit AVR mikrodenetleyici (Arduino Uno)",
    "pin.desc.78xx": "Pozitif sabit regülatör",
    "pin.desc.79xx": "Negatif sabit regülatör",
    "pin.desc.lm317": "Ayarlı pozitif regülatör",
    "pin.desc.ams1117": "LDO regülatör",
    "pin.desc.irfz44n": "N kanal güç MOSFET'i",
    "pin.desc.bc547": "NPN transistör",
    "pin.desc.2n2222": "NPN transistör",
    "pin.desc.lm35": "Sıcaklık sensörü (10 mV/°C)",
    "pin.desc.ds18b20": "1-Wire dijital sıcaklık sensörü",
    "pin.desc.tl431": "Ayarlı şönt referans",
})

# --- 0.7: terminal arayüzü ---------------------------------------------------------------
MESSAGES.update({
    "tui.help": "Terminal arayüzü: komutu seç, formu doldur, sonucu gör.\n\nTuşlar: Ctrl+R çalıştır · Ctrl+F ara · F2/F3/F4 sekmeler · Ctrl+L temizle · Ctrl+Q çık",
    "tui.need_textual": "terminal arayüzü için Textual gerekli: {pip}",
    "menu.tui": "Terminal arayüzü",
    "tui.key.run": "Çalıştır",
    "tui.key.clear": "Temizle",
    "tui.key.search": "Ara",
    "tui.key.quit": "Çık",
    "tui.tab.calc": "Hesaplar",
    "tui.tab.circuit": "Devre",
    "tui.tab.history": "Geçmiş",
    "tui.search": "Komut ara…",
    "tui.commands": "Komutlar",
    "tui.pick": "Soldan bir komut seç",
    "tui.cmdline": "Komut satırı — düzenle ya da bir komut yazıp Enter'a bas",
    "tui.run": "▶ Çalıştır",
    "tui.welcome": "Bir komut seç, alanları doldur ve Enter ya da Ctrl+R'ye bas. Komut satırına istediğin elektro komutunu da yazabilirsin.",
    "tui.blocked": "'{cmd}' arayüzün içinde çalıştırılamaz",
    "tui.hist.hint": "Enter: komutu Hesaplar sekmesine yükle",
    "tui.col.time": "Zaman",
    "tui.col.command": "Komut",
    "tui.help_examples": "Yardım ve örnekler",
})

# --- 0.7: devre editörü ve simülatör ------------------------------------------------------
MESSAGES.update({
    "ckt.bad_file": "geçerli bir elektro devre dosyası değil",
    "ckt.singular": "devre çözülemiyor: boşta kalan bir eleman, gerilim kaynağı/bobin döngüsü ya da kondansatörle seri akım kaynağı var",
    "ckt.empty": "devre boş",
    "ckt.no_ground": "devrede toprak (GND) yok",
    "ckt.shorted": "{ref} kısa devre (iki ucu aynı düğümde)",
    "ckt.open_pin": "{ref} elemanının bir ucu boşta",
    "ckt.bad_value": "{ref} için geçersiz değer",
    "ckt.key.wire": "Kablo",
    "ckt.key.rotate": "Döndür",
    "ckt.key.undo": "Geri al",
    "ckt.key.simulate": "Çöz",
    "ckt.key.save": "Kaydet",
    "ckt.key.open": "Aç",
    "ckt.msg.placed": "{ref} yerleştirildi — e: değer, Ctrl+R: döndür, m: taşı",
    "ckt.msg.wire": "Kablo: imleci gezdir, Enter/w köşe koyar, Esc bitirir",
    "ckt.msg.move": "{ref} taşınıyor: oklar taşır, Enter/m bırakır, Esc vazgeçer",
    "ckt.msg.undone": "Geri alındı.",
    "ckt.msg.solved": "DC çalışma noktası çözüldü. Düzenledikçe sonuç güncellenir.",
    "ckt.msg.saved": "Kaydedildi: {path}",
    "ckt.msg.opened": "Açıldı: {path}",
    "ckt.msg.new": "Yeni devre (Ctrl+Z eskisini geri getirir).",
    "ckt.prompt.value": "{ref} değeri ({unit}) — ör. 4k7, 100n, 12",
    "ckt.prompt.save": "Farklı kaydet (JSON dosyası)",
    "ckt.prompt.open": "Devre dosyası aç",
    "ckt.untitled": "adsız",
    "ckt.mode.normal": "düzenle",
    "ckt.mode.wire": "KABLO",
    "ckt.mode.move": "TAŞI",
    "ckt.kind.R": "direnç",
    "ckt.kind.C": "kondansatör",
    "ckt.kind.L": "bobin",
    "ckt.kind.V": "gerilim kaynağı",
    "ckt.kind.I": "akım kaynağı",
    "ckt.kind.GND": "toprak",
    "ckt.nodes": "Düğümler",
    "ckt.node": "Düğüm",
    "ckt.op_title": "DC çalışma noktası",
    "tui.arg": "Devre sekmesinde açılacak devre dosyası",
    "menu.sim": "Devre dosyasını çöz",
    "sim.arg": "Devre dosyası (.json, elektro tui ile kaydedilen)",
    "sim.opt.spice": "Çözmek yerine SPICE netlist'ini yaz",
    "sim.nodes": "Düğüm gerilimleri",
    "sim.elements": "Elemanlar",
    "sim.note": "DC: kondansatör açık devre, bobin kısa devre sayılır. P > 0 tüketir, P < 0 güç verir.",
    "ckt.key.probe": "Probe",
    "ckt.msg.probe_added": "Probe eklendi: {expr}",
    "ckt.msg.probe_removed": "Probe kaldırıldı: {expr}",
    "ckt.msg.nothing": "Burada ölçülecek bir şey yok: bir düğüme, kabloya ya da elemana git.",
    "ckt.msg.probe_from": "{a} noktasından akım probe'u: diğer düğüme git, a/Enter bas (Esc vazgeçer)",
    "ckt.probes": "Probe'lar",
    "ckt.probe.no_net": "{addr} bir düğümün üzerinde değil",
    "ckt.probe.no_part": "{ref} adında eleman yok",
    "ckt.probe.same": "{a} ve {b} aynı düğümde",
    "ckt.probe.no_path": "{a} ile {b} arasında doğrudan bağlı eleman yok",
    "sim.opt.probe": "Ek probe, ör. -p \"V(C3)\" -p \"I(C1,C10)\" (tekrarlanabilir)",
    "ckt.mode.probe": "AKIM PROBE",
    "ckt.msg.req_from": "{a} noktasından eşdeğer direnç: diğer noktaya git, o/Enter bas (Esc vazgeçer)",
    "ckt.msg.no_source": "Devrede kaynak yok: DC çözülecek bir şey yok, direnç probe'ları R(A,B) yine çalışır (o).",
    "sim.need_req": "devrede kaynak yok; eşdeğer direnç için -p \"R(A1,D1)\" gibi bir probe ekle",
    "src.bad": "geçersiz kaynak değeri '{text}' (örnekler: 5, DC 5 AC 1, SINE(0 1 1k), PULSE(0 5 0 1u 1u 0.5m 1m))",
    "src.bad_number": "sayı değil: '{text}'",
    "src.bad_wave": "{name} parametre sayısı yanlış",
    "an.bad": "geçersiz analiz '{text}' (örnekler: .op, .tran 10m, .ac dec 100 10 100k, .dc V1 0 5 0.1)",
    "an.bad_tran": ".tran için pozitif bir bitiş süresi (ve ondan büyük olmayan bir adım) gerekli",
    "an.bad_ac": ".ac için nokta sayısı ≥ 1 ve 0 < başlangıç < bitiş frekansı olmalı",
    "an.bad_dc": ".dc: adım başlangıçtan bitişe doğru gitmeli",
    "an.no_ac_source": "AC kaynak yok: bir kaynağa AC değeri ver, ör. 'AC 1' ya da 'DC 0 AC 1'",
    "an.no_source": "{ref} adında gerilim/akım kaynağı yok",
    "an.title": "Analiz — LTspice komutu yaz ya da formu doldur",
    "an.kind": "Analiz",
    "an.kind.op": "DC çalışma noktası (.op)",
    "an.kind.tran": "Zaman (.tran)",
    "an.kind.ac": "AC tarama (.ac)",
    "an.kind.dc": "DC tarama (.dc)",
    "an.tstop": "Bitiş süresi",
    "an.tstep": "Zaman adımı",
    "an.auto": "otomatik",
    "an.sweep": "Tarama",
    "an.points": "Nokta (dekad/oktav başına)",
    "an.fstart": "Başlangıç frekansı",
    "an.fstop": "Bitiş frekansı",
    "an.source": "Kaynak",
    "an.start": "Başlangıç",
    "an.stop": "Bitiş",
    "an.step": "Adım",
    "an.ok": "Tamam",
    "an.cancel": "Vazgeç",
    "plot.key.mode": "Genlik/faz",
    "plot.key.size": "Grafik boyutu",
    "plot.hint": "Henüz analiz yok: editörde s'ye bas (.tran/.ac/.dc), sonra F5. Probe'lar (p) eğri olur.",
    "ckt.key.analysis": "Analiz",
    "ckt.msg.analysis": "Analiz: {directive}",
    "ckt.prompt.source": "{ref} değeri ({unit}) — ör. 5 · AC 1 · SINE(0 1 1k) · PULSE(0 5 0 1u 1u 0.5m 1m)",
    "ckt.analysis": "Analiz",
    "ckt.running": "hesaplanıyor…",
    "sim.opt.analysis": "Dosyadaki yerine bu analizi çalıştır, ör. \".tran 5m\" (\".op\": yalnız DC)",
    "sim.opt.csv": "Eğrileri CSV olarak kaydet",
    "sim.points": "nokta",
    "sim.max_db": "en büyük",
    "sim.at": "frekans",
    "sim.last": "son",
    "sim.sweep_x": "Tarama",
    "sim.csv_saved": "CSV kaydedildi: {path}",
    "sim.help": "TUI'de çizilen devre dosyasını çözer: DC çalışma noktası ve dosyadaki analiz (.tran, .ac, .dc).\n\nDüğümler Excel hücreleri gibi adlandırılır (B2, E7). Probe'lar: V(C3), V(C3,E7), I(C1,C10), I(R1), P(R1), R(A1,D1). Kaynaklar: 5, AC 1, SINE(0 1 1k), PULSE(0 5 0 1u 1u 0.5m 1m).\n\nÖrnekler:\n  elektro sim bolucu.json -p \"V(E2)\"\n  elektro sim rc.json -a \".tran 5m\" --plot rc.svg\n  elektro sim filtre.json -a \".ac dec 50 10 1meg\" --csv bode.csv\n  elektro sim bolucu.json --spice > bolucu.cir",
    "dev.unknown": "bilinmeyen model '{name}' (modeller: {options}; ya da IS=1e-14 gibi parametreler)",
    "dev.bad_rail": "geçersiz çıkış sınırı '{text}' (örnekler: ±15, 0..5)",
    "dev.bad_param": "geçersiz parametre '{text}'",
    "ckt.no_converge": "çözüm yakınsamadı (devreyi kontrol et: diyot/transistörü doğrudan süren bir kaynak, eksik bir direnç…)",
    "ckt.probe.no_pin": "{ref} elemanında '{pin}' ucu yok (uçlar: {pins})",
    "ckt.probe.no_ac_power": "AC analizde güç gösterilmez",
    "ckt.prompt.model.D": "Diyot {ref}: {models} — ya da IS=… N=… RS=… BV=…",
    "ckt.prompt.model.Q": "Transistör {ref}: {models} — ya da NPN/PNP BF=… IS=… VAF=…",
    "ckt.prompt.model.M": "MOSFET {ref}: {models} — ya da NMOS/PMOS VTO=… KP=… LAMBDA=…",
    "ckt.prompt.model.U": "Op-amp {ref}: {models} — çıkış sınırı ör. 'TL072 ±15', 'LM358 0..5'",
    "ckt.kind.D": "diyot",
    "ckt.kind.Q": "bipolar transistör",
    "ckt.kind.M": "MOSFET",
    "ckt.kind.U": "op-amp",
    "ckt.prompt.probe": "Probe: V(C3) · V(C3,E7) · I(C1,C10) · I(R1) · I(Q1.B) · P(R1) · R(A1,D1)   (-2 2. probe'u, - hepsini siler)",
    "ckt.probe.bad": "geçersiz probe '{expr}' (örnekler: V(C3), V(C3,E7), I(C1,C10), I(R1), I(Q1.B), P(R1), R(A1,D1))",
    "tui.circuit.keys": "r R · c C · l L · v V · i I · d diyot · q BJT · f MOSFET · u op-amp · n etiket · g GND · w kablo · e/Enter değer · Ctrl+R döndür · m taşı · x sil · p probe · a iki düğüm arası akım · o direnç · P probe yaz · s analiz · F5 çöz · F6 grafik boyutu · Tab grafik (←/→ imleç, m genlik/faz) · Ctrl+Z geri al · Ctrl+S kaydet · Ctrl+O aç · Ctrl+N yeni · Ctrl+E örnekler",
    "ckt.probes_at": "Probe'lar ({x} anında)",
    "ckt.col.peak": "tepe",
    "ckt.kind.N": "düğüm etiketi",
    "ckt.prompt.label": "Düğüm etiketi adı (ör. VCC, OUT, IN); aynı adlı noktalar birbirine bağlıdır",
    "ckt.bad_label": "geçersiz ad '{name}' (harf, rakam, _; harfle başlamalı)",
    "ckt.msg.label": "{name} etiketi kondu",
    "spice.dropped": "{model}: modellenmeyen parametreler yok sayıldı: {params}",
    "spice.unknown_model": "'{model}' modeli bulunamadı; genel model kullanılıyor",
    "spice.skipped": "satır atlandı: {line}",
    "spice.empty": "netlist'te desteklenen eleman yok",
    "ckt.msg.imported": "{path} içe aktarıldı (elemanlar otomatik dizildi, etiketlerle bağlı)",
    "ex.divider": "Gerilim bölücü (12 V → 3.84 V)",
    "ex.bridge": "Wheatstone köprüsü, eşdeğer direnç",
    "ex.rc_charge": "RC dolma eğrisi",
    "ex.rc_lowpass": "RC alçak geçiren filtre (Bode)",
    "ex.rlc_bandpass": "Seri RLC bant geçiren (1.6 kHz)",
    "ex.half_wave": "Yarım dalga doğrultucu + filtre",
    "ex.bridge_rectifier": "Köprü doğrultucu",
    "ex.zener": "Zener regülatör (giriş taraması)",
    "ex.led_driver": "Transistörlü LED sürücü",
    "ex.common_emitter": "Ortak emetörlü yükselteç",
    "ex.mosfet_switch": "MOSFET ile PWM anahtarlama",
    "ex.non_inverting": "Evirmeyen yükselteç (×11)",
    "ex.inverting": "Eviren yükselteç (×−10)",
    "ex.integrator": "Entegratör (kare → üçgen)",
    "ex.comparator": "Karşılaştırıcı (sinüs → kare)",
    "ex.cat.basic": "Temel",
    "ex.cat.filters": "Filtreler",
    "ex.cat.power": "Güç",
    "ex.cat.transistor": "Transistör",
    "ex.cat.opamp": "Op-amp",
    "ex.help": "Hazır örnek devreler.\n\nÖrnekler:\n  elektro examples                 (liste)\n  elektro examples rc_lowpass      (rc_lowpass.json olarak kaydet)\n  elektro examples zener -o z.json\n\n`elektro tui` Devre sekmesinde: Ctrl+E.",
    "ex.arg": "Örnek adı (boş bırakılırsa liste)",
    "ex.opt.output": "Yazılacak dosya (varsayılan: AD.json)",
    "ex.saved": "Örnek kaydedildi: {path}",
    "ex.unknown": "bilinmeyen örnek '{name}' (örnekler: {options})",
    "ex.usage": "Birini kaydet: elektro examples AD   ·   editörde: Ctrl+E",
    "ex.title": "Örnek devreler — Enter açar, Esc vazgeçer",
    "ckt.key.examples": "Örnekler",
    "ckt.msg.example": "Örnek: {title} (Ctrl+S ile kaydedilir)",
    "menu.examples": "Örnek devreler",
})
